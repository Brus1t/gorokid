# 原创素材记录

2026-10-07，使用内置 image_gen 从文字生成，无第三方参考图。
交付文件：Assets/Scripts/ARCardPrototype/Resources/InkBattlefield.png。

完整提示词：

Original premium dark Chinese ink-fantasy game background for a widescreen 16:9 tactical card game. Painterly richly detailed digital concept art, not a screenshot or UI. At far left an original female strategist in dark jade robes and bronze armor facing inward, chest-up portrait at outer left 20 percent. At far right an original male warrior in weathered crimson lamellar armor facing inward, portrait at outer right 20 percent. Both faces at upper third. No known or copyrighted characters. Center 60 percent is dark misty ancient circular stone strategy table with brass concentric inlays, extremely subtle misty mountains behind. Bottom 35 percent is dark uncluttered negative space reserved for code-rendered hand cards. Top 12 percent dark empty. Ink teal, antique gold, muted vermilion palette, cinematic rim light, atmospheric ink brush textures. High production quality, sophisticated and restrained. No text, no lettering, no logos, no cards, no UI, no watermarks. Landscape 16:9.

卡牌、文字和战斗特效由代码绘制。音效由 SynthCombatAudio 合成，不含第三方采样。系统字体不随包分发。
