using System;
using System.Collections.Generic;
using ARCardPrototype;

// Compiled separately from Unity. Kept outside Assets intentionally.
public static class CoreTests
{
    private static int checks;
    private static void Check(bool ok, string message)
    {
        checks++;
        if (!ok) throw new Exception("FAILED: " + message);
    }
    private static int Find(GameManager g, CardType type)
    {
        for (int i = 0; i < g.ActingPlayer.Hand.Count; i++)
            if (g.ActingPlayer.Hand[i].Type == type) return i;
        throw new Exception("Missing card " + type);
    }
    private static void Attack(GameManager g)
    {
        Check(g.SelectCard(Find(g, CardType.Attack)), "select Attack");
        Check(g.SelectPlayer(1 - g.CurrentPlayer.Id), "select opponent");
        Check(g.Confirm(), "play Attack");
    }
    public static void Main()
    {
        GameManager g = new GameManager();
        int changed = 0, logged = 0;
        g.Changed += () => changed++;
        g.Logged += message => logged++;
        Check(g.Players.Count == 2 && g.Players[0].Health == 4 && g.Players[1].Health == 4, "initial HP");
        Check(g.Players[0].Hand.Count == 6 && g.Players[1].Hand.Count == 4, "initial hand + draw");
        Check(!g.SelectCard(-1) && !g.SelectCard(100) && !g.SelectPlayer(2), "bad indices rejected");
        Check(!g.Confirm() && !g.SkipResponse(), "empty actions rejected");
        g.SelectCard(2);
        Check(!g.Confirm() && g.CurrentPlayer.Hand.Count == 6, "full-health Peach not consumed");
        g.SelectCard(1);
        Check(!g.Confirm() && g.CurrentPlayer.Hand.Count == 6, "proactive Dodge rejected");
        g.SelectCard(0);
        Check(!g.Confirm(), "missing target rejected");
        g.SelectPlayer(0);
        Check(!g.Confirm() && g.CurrentPlayer.Hand.Count == 6, "self attack rejected");
        Attack(g);
        Check(g.Phase == GamePhase.AwaitingDodge && g.ActingPlayer.Id == 1 && g.CurrentPlayer.Id == 0, "defender control");
        Check(g.Players[0].Hand.Count == 5 && g.Turns.AttackUsed, "attack consumed once");
        Check(!g.EndTurn() && !g.SelectPlayer(0), "response blocks end turn and target selection");
        g.SelectCard(0);
        Check(!g.Confirm() && g.Players[1].Hand.Count == 4, "response must be Dodge");
        g.Cancel();
        Check(g.Phase == GamePhase.AwaitingDodge, "cancel cannot undo Attack");
        g.SelectCard(1);
        Check(g.Confirm() && g.Players[1].Health == 4 && g.Players[1].Hand.Count == 3, "Dodge avoids damage");
        Check(g.ActingPlayer.Id == 0 && g.SelectedCardIndex == -1 && g.SelectedTargetId == -1, "response restores attacker and clears selection");
        g.SelectCard(Find(g, CardType.Attack)); g.SelectPlayer(1);
        Check(!g.Confirm() && g.Players[0].Hand.Count == 5, "one Attack per turn");
        Check(g.EndTurn() && g.CurrentPlayer.Id == 1 && g.Turns.TurnNumber == 2, "turn alternation");
        Check(!g.Turns.AttackUsed && g.Players[0].Hand.Count == 4 && g.Players[1].Hand.Count == 5, "discard draw and reset");
        Attack(g);
        Check(g.SkipResponse() && g.Players[0].Health == 3, "declining response damages");
        g.EndTurn();
        g.SelectCard(Find(g, CardType.Peach));
        Check(g.SelectedTargetId == 0, "Peach auto targets self");
        g.SelectPlayer(1);
        int handCount = g.CurrentPlayer.Hand.Count;
        Check(!g.Confirm() && g.CurrentPlayer.Hand.Count == handCount, "Peach cannot heal opponent");
        g.SelectPlayer(0);
        Check(g.Confirm() && g.Players[0].Health == 4 && g.CurrentPlayer.Hand.Count == handCount - 1, "Peach heals and consumed");
        Check(changed > 0 && logged > 0, "events emitted");

        g.Restart();
        Check(g.Turns.TurnNumber == 1 && g.CurrentPlayer.Id == 0 && g.Players[0].Health == 4 && g.WinnerId == -1, "restart reset");
        // Find enough generated Attack cards through legal turns, with opponent passing.
        int guard = 0;
        while (g.Phase != GamePhase.GameOver && guard++ < 100)
        {
            if (g.CurrentPlayer.Id == 0)
            {
                int attack = -1;
                for (int i = 0; i < g.CurrentPlayer.Hand.Count; i++)
                    if (g.CurrentPlayer.Hand[i].Type == CardType.Attack) { attack = i; break; }
                if (attack >= 0) { Attack(g); g.SkipResponse(); }
            }
            if (g.Phase != GamePhase.GameOver) g.EndTurn();
        }
        Check(g.Phase == GamePhase.GameOver && g.WinnerId == 0 && g.Players[1].Health == 0, "lethal damage and winner");
        Check(!g.Confirm() && !g.EndTurn() && !g.SkipResponse() && !g.SelectCard(0) && !g.SelectPlayer(1) && !g.Cancel(), "game over locks commands");
        Check(g.Players[1].Health == 0, "HP never negative");
        g.Restart();
        Check(g.Phase == GamePhase.Playing && g.Players[1].Health == 4 && g.Players[1].Hand.Count == 4, "restart after victory");
        var events = new List<CombatEvent>();
        g.Events.Published += events.Add;
        Attack(g);
        Check(events.Count == 1 && events[0] is AttackDeclaredEvent, "attack event before damage");
        Check(g.Players[1].Health == 4, "Attack declaration alone does not damage");
        g.SelectCard(1); g.Confirm();
        Check(events.Count == 2 && events[1] is DodgeEvent, "Dodge emits no DamageEvent");
        g.Restart(); events.Clear();
        Attack(g); g.SkipResponse();
        DamageEvent hit = events[1] as DamageEvent;
        Check(events.Count == 2 && hit != null && hit.Amount == 1 && hit.OldHealth == 4 && hit.NewHealth == 3 && hit.TargetId == 1 && hit.SourceId == 0, "damage snapshot values");
        Check(g.Players[1].Health == 3, "damage committed without presentation");
        g.EndTurn(); g.SelectCard(2); g.Confirm();
        HealEvent recovery = events[2] as HealEvent;
        Check(recovery != null && recovery.OldHealth == 3 && recovery.NewHealth == 4, "healing event");
        Check(hit.NewHealth == 3, "event snapshots immutable after later healing");
        Check(TargetingRules.Allows(CardType.Attack, 0, 1) && !TargetingRules.Allows(CardType.Attack, 0, 0) &&
            TargetingRules.Allows(CardType.Peach, 1, 1) && !TargetingRules.Allows(CardType.Peach, 1, 0) &&
            !TargetingRules.Allows(CardType.Dodge, 0, 1) && !TargetingRules.Allows(CardType.Attack, 0, 9), "shared target policy");
        Console.WriteLine("PASS: " + checks + " checks covering rules, transitions, invalid actions, events and restart.");
    }
}
