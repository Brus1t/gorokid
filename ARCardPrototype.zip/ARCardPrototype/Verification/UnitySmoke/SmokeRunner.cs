using System;
using System.Collections;
using System.IO;
using UnityEngine;
using ARCardPrototype;
#if UNITY_EDITOR
using UnityEditor;
#endif

public sealed class SmokeRunner : MonoBehaviour
{
    private int checks;
    private bool failed;
    private string output;
    private void Check(bool success, string message)
    {
        checks++;
        if (!success) { failed = true; Debug.LogError("SMOKE FAILED: " + message); }
    }
    private void OnEnable() { Application.logMessageReceived += OnLog; }
    private void OnDisable() { Application.logMessageReceived -= OnLog; }
    private void OnLog(string condition, string trace, LogType type)
    {
        if (type == LogType.Exception || type == LogType.Error) failed = true;
    }
    private IEnumerator Start()
    {
        Application.runInBackground = true;
        output = Path.GetFullPath(Path.Combine(Application.dataPath, "../../"));
        yield return null;
#if !UNITY_EDITOR
        while (!UnityEngine.Rendering.SplashScreen.isFinished) yield return null;
        yield return new WaitForSecondsRealtime(0.3f);
#endif
        var bootstrap = FindObjectOfType<GameBootstrap>();
        var game = bootstrap.Game;
        var presenter = bootstrap.GetComponent<CombatPresenter>();
        var input = bootstrap.GetComponent<PCInput>();
        var bar = presenter.GetView(1).HealthBar;
        Check(Mathf.Approximately(bar.DisplayedRatio, 1), "initial bar");
        Capture("01-initial.png");
#if !UNITY_EDITOR
        ScreenCapture.CaptureScreenshot(Path.Combine(output, "06-full-ui.png"));
        yield return new WaitForSecondsRealtime(0.25f);
#endif
        input.SelectCard(0); input.SelectPlayer(1); input.Confirm();
        yield return new WaitForSecondsRealtime(0.15f);
        Capture("02-attack.png");
        input.SkipResponse();
        Check(game.Players[1].Health == 3, "immediate authoritative HP");
        yield return new WaitForSecondsRealtime(0.32f);
        Check(bar.DisplayedRatio < 1 && bar.DisplayedRatio > 0.75f, "bar has intermediate value");
        Check(presenter.GetView(1).Feedback.IsPlaying, "hit feedback active");
        Capture("03-damage.png");
        yield return new WaitForSecondsRealtime(0.6f);
        Check(Mathf.Abs(bar.DisplayedRatio - 0.75f) < 0.001f, "bar reaches 3/4");
        Check(!presenter.GetView(1).Feedback.IsPlaying, "hit feedback restores rest pose");
        Capture("04-settled.png");
        input.EndTurn(); input.SelectCard(2); input.Confirm();
        yield return new WaitForSecondsRealtime(0.65f);
        Check(game.Players[1].Health == 4 && Mathf.Approximately(bar.DisplayedRatio, 1), "healing display");
        game.Restart();
        input.SelectCard(0); input.SelectPlayer(1); input.Confirm();
        input.SelectCard(1); input.Confirm();
        yield return new WaitForSecondsRealtime(0.6f);
        Check(game.Players[1].Health == 4 && Mathf.Approximately(bar.DisplayedRatio, 1), "Dodge preserves HP and bar");
        Capture("05-dodge.png");
        game.Restart();
        input.SelectCard(0); input.SelectPlayer(1); input.Confirm(); input.SkipResponse();
        game.Restart();
        yield return new WaitForSecondsRealtime(0.8f);
        Check(presenter.PendingCount == 0 && Mathf.Approximately(bar.DisplayedRatio, 1), "restart discards queued old damage");
        Check(presenter.PopupPoolSize == 4 && presenter.AttackPoolSize == 2, "effects reused from warm pool");
        presenter.enabled = false;
        input.SelectCard(0); input.SelectPlayer(1); input.Confirm(); input.SkipResponse();
        Check(game.Players[1].Health == 3, "logic works with presentation disabled");
        presenter.enabled = true;
        Check(Mathf.Approximately(bar.DisplayedRatio, 0.75f), "reenabled presenter syncs current state");
        game.Restart();
        yield return null;
        string result = (failed ? "FAIL" : "PASS") + ": " + checks + " Unity runtime checks.";
        File.WriteAllText(Path.Combine(output,
#if UNITY_EDITOR
            "unity-smoke-result.txt"
#else
            "standalone-smoke-result.txt"
#endif
        ), result);
        Debug.Log(result);
#if UNITY_EDITOR
        EditorApplication.Exit(failed ? 1 : 0);
#else
        Application.Quit(failed ? 1 : 0);
#endif
    }

    private void Capture(string filename)
    {
        Camera camera = GameObject.Find("PrototypeCamera").GetComponent<Camera>();
        var texture = new RenderTexture(1000, 800, 24);
        Rect oldRect = camera.rect;
        RenderTexture oldTarget = camera.targetTexture;
        RenderTexture oldActive = RenderTexture.active;
        camera.rect = new Rect(0, 0, 1, 1);
        camera.targetTexture = texture;
        camera.Render();
        RenderTexture.active = texture;
        var pixels = new Texture2D(1000, 800, TextureFormat.RGB24, false);
        pixels.ReadPixels(new Rect(0, 0, 1000, 800), 0, 0);
        pixels.Apply();
        File.WriteAllBytes(Path.Combine(output, filename), pixels.EncodeToPNG());
        camera.targetTexture = oldTarget;
        camera.rect = oldRect;
        RenderTexture.active = oldActive;
        Destroy(pixels); texture.Release(); Destroy(texture);
    }
}
