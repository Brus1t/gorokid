using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using ARCardPrototype;

public static class SmokeEntry
{
    public static void BuildDemo()
    {
        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        new GameObject("ARCardGame").AddComponent<GameBootstrap>();
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), "Assets/Demo.unity");
        PlayerSettings.productName = "MOJU - 墨局";
        PlayerSettings.defaultScreenWidth = 1600;
        PlayerSettings.defaultScreenHeight = 900;
        PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
        PlayerSettings.runInBackground = true;
        var report = BuildPipeline.BuildPlayer(new[] { "Assets/Demo.unity" },
            "../MojuDemo/Moju.exe", BuildTarget.StandaloneWindows64, BuildOptions.None);
        EditorApplication.Exit(report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded ? 0 : 1);
    }
    public static void BuildTabletopTest()
    {
        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        new GameObject("ARCardGame").AddComponent<GameBootstrap>();
        new GameObject("TabletopValidation").AddComponent<TabletopSmokeRunner>();
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), "Assets/TabletopTest.unity");
        PlayerSettings.productName = "MOJU - Visual Verification";
        PlayerSettings.defaultScreenWidth = 1600; PlayerSettings.defaultScreenHeight = 900;
        PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
        PlayerSettings.runInBackground = true;
        var report = BuildPipeline.BuildPlayer(new[] { "Assets/TabletopTest.unity" },
            "../TabletopTest/MojuTest.exe", BuildTarget.StandaloneWindows64, BuildOptions.Development);
        EditorApplication.Exit(report.summary.result == UnityEditor.Build.Reporting.BuildResult.Succeeded ? 0 : 1);
    }
}

