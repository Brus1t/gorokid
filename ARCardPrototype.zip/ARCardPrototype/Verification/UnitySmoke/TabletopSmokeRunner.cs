using System;
using System.Collections;
using System.IO;
using UnityEngine;
using ARCardPrototype;

public sealed class TabletopSmokeRunner : MonoBehaviour
{
    private int checks;
    private bool failed;
    private string output;
    private void Check(bool value, string name)
    { checks++; if (!value) { failed = true; Debug.LogError("CHECK FAILED: " + name); } }
    private void OnEnable() { Application.logMessageReceived += Log; }
    private void OnDisable() { Application.logMessageReceived -= Log; }
    private void Log(string message, string trace, LogType type)
    { if (type == LogType.Exception || type == LogType.Error) failed = true; }
    private IEnumerator Capture(string name)
    {
        yield return new WaitForEndOfFrame();
        Texture2D picture = ScreenCapture.CaptureScreenshotAsTexture();
        File.WriteAllBytes(Path.Combine(output, name), picture.EncodeToPNG());
        Destroy(picture);
        yield return null;
    }
    private IEnumerator Start()
    {
        Application.runInBackground = true;
        output = Path.GetFullPath(Path.Combine(Application.dataPath, "../../TabletopPreview"));
        Directory.CreateDirectory(output);
        while (!UnityEngine.Rendering.SplashScreen.isFinished) yield return null;
        yield return new WaitForSecondsRealtime(1);
        var bootstrap = FindObjectOfType<GameBootstrap>();
        var game = bootstrap.Game;
        var visual = bootstrap.GetComponent<TabletopPresenter>();
        var input = bootstrap.GetComponent<PCInput>();
        var director = bootstrap.GetComponent<DemoDirector>();
        Check(game.Players.Count == 2 && visual.Health[0] == 4 && visual.Health[1] == 4, "initial state");
        Check(Resources.Load<Texture2D>("InkBattlefield") != null, "background bundled");
        yield return Capture("01-table.png");
        input.SelectCard(0); input.SelectPlayer(1);
        yield return new WaitForSecondsRealtime(0.3f);
        yield return Capture("02-selected.png");
        input.Confirm();
        input.SkipResponse();
        Check(game.Players[1].Health == 4, "input gate blocks response during animation");
        yield return new WaitForSecondsRealtime(0.9f);
        yield return Capture("03-attack.png");
        while (visual.IsBusy) yield return null;
        input.SkipResponse();
        Check(game.Players[1].Health == 3, "authoritative damage");
        yield return new WaitForSecondsRealtime(0.17f);
        Check(visual.Health[1] > 3 && visual.Health[1] < 4, "smooth health intermediate");
        Check(visual.HealthShadow[1] > visual.Health[1], "delayed health trail");
        yield return Capture("04-impact.png");
        while (visual.IsBusy) yield return null;
        Check(Mathf.Abs(visual.Health[1] - 3) < 0.001f, "health settles");
        input.EndTurn(); input.SelectCard(2); input.Confirm();
        yield return new WaitForSecondsRealtime(0.2f);
        yield return Capture("05-heal.png");
        while (visual.IsBusy) yield return null;
        Check(game.Players[1].Health == 4 && Mathf.Approximately(visual.Health[1], 4), "heal display");
        game.Restart();
        input.SelectCard(0); input.SelectPlayer(1); input.Confirm();
        while (visual.IsBusy) yield return null;
        input.SelectCard(1); input.Confirm();
        yield return new WaitForSecondsRealtime(0.2f);
        yield return Capture("06-dodge.png");
        while (visual.IsBusy) yield return null;
        Check(game.Players[1].Health == 4 && visual.Health[1] == 4, "Dodge no damage");
        game.Restart(); input.SelectCard(0); input.SelectPlayer(1); input.Confirm(); game.Restart();
        Check(!visual.IsBusy && visual.PendingCount == 0 && visual.Health[1] == 4, "restart flushes queue");
        director.Play();
        Check(director.IsRunning, "demo starts");
        int turnBefore = game.Turns.TurnNumber; input.EndTurn();
        Check(game.Turns.TurnNumber == turnBefore, "user input gated during demo");
        while (director.IsRunning) yield return null;
        Check(game.Players[1].Health == 4 && director.Step == 3 && game.Turns.TurnNumber == 2, "full demo ends after healing");
        input.EndTurn();
        Check(game.Turns.TurnNumber == 3, "input restored after demo");
        director.Play(); yield return new WaitForSecondsRealtime(0.2f); director.Stop();
        Check(!director.IsRunning && !visual.IsBusy && game.Turns.TurnNumber == 1, "stop resets cleanly");
        visual.enabled = false;
        game.SelectCard(0); game.SelectPlayer(1); game.Confirm(); game.SkipResponse();
        Check(game.Players[1].Health == 3, "rules independent of visual layer");
        visual.enabled = true;
        Check(visual.Health[1] == 3, "reenable snapshot");
        string result = (failed ? "FAIL" : "PASS") + ": " + checks + " tabletop runtime checks";
        File.WriteAllText(Path.Combine(output, "result.txt"), result);
        Debug.Log(result); Application.Quit(failed ? 1 : 0);
    }
}
