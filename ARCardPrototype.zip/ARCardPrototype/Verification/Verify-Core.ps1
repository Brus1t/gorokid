param([Parameter(Mandatory=$true)][string]$UnityEditorPath)
$ErrorActionPreference='Stop'
# Windows helper validated with Unity 6000.3.18f1's bundled compiler.
$data=Join-Path $UnityEditorPath 'Data'
$refs=Join-Path $data 'UnityReferenceAssemblies/unity-4.8-api'
$package=Split-Path $PSScriptRoot
$output=Join-Path ([IO.Path]::GetTempPath()) ('ARCardCoreTests-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $output | Out-Null
$scripts=Join-Path $package 'Assets/Scripts/ARCardPrototype'
$files=Get-ChildItem (Join-Path $scripts 'GameLogic'),(Join-Path $scripts 'CombatEvents') -Recurse -Filter '*.cs' | Select-Object -ExpandProperty FullName
$exe=Join-Path $output 'CoreTests.exe'
& (Join-Path $data 'NetCoreRuntime/dotnet.exe') (Join-Path $data 'DotNetSdkRoslyn/csc.dll') -nologo -noconfig -nostdlib -langversion:9 -target:exe ('-out:'+$exe) ('-r:'+(Join-Path $refs 'mscorlib.dll')) ('-r:'+(Join-Path $refs 'System.dll')) ('-r:'+(Join-Path $refs 'System.Core.dll')) $files (Join-Path $PSScriptRoot 'CoreTests.cs')
if($LASTEXITCODE -ne 0){throw 'Core test compilation failed.'}
& $exe
if($LASTEXITCODE -ne 0){throw 'Core tests failed.'}
Write-Output ('Test binary: '+$exe)
