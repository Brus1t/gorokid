# Research references and attribution

No third-party source implementation, artwork, card face, logo, prefab, animation,
texture, shader asset, or audio file from the following repositories is included
in the distributable Assets folder. The implementation uses original prototype
code and Unity built-in primitives and APIs.

Design research sources:

* wyx-0203/sgs-unity — https://github.com/wyx-0203/sgs-unity
  Inspected commit: c6666cf5e2b6b9e561d40308bcd67752472f1629.
  No applicable code license was located in the inspected root, README or Scripts.
  Referenced concepts: independent rules, action/response flow, target validation.
* i-Jiro/Unity3D-Turn_Based_RPG — https://github.com/i-Jiro/Unity3D-Turn_Based_RPG
  Inspected commit: 1b546f4b3439db7fd96f062332a8a120e1d2dc09.
  Upstream license: GNU GPL v3 (see upstream LICENSE).
  Referenced concepts: event-driven presentation, popup lifetimes, object pooling.
  No GPL source code is incorporated or adapted into this package.
* Dartteon/UnityHealthBar — https://github.com/Dartteon/UnityHealthBar
  Inspected commit: 3f2ed9b9cd3ee4813b6c45130a60219b2506010e,
  including package script contents.
  No applicable license located in the inspected root, README or package scripts.
  Referenced concept: separating health state from its display.
  The package's BarUI updates instantly; smoothing here is a new implementation.

This notice records research provenance; it does not grant rights to upstream
code or assets. If third-party code is incorporated later, reassess its license
and include the required license text, attribution and modification notices.

Version 0.3 includes an original image generated with built-in image_gen (ART_PROVENANCE.md), code-rendered UI and synthesized audio. No assets from the reference repositories are included.
