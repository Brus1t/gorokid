using System;

namespace ARCardPrototype
{
    // Transport only; no game rules, engine objects or animation timing.
    // The presenter subscribes and keeps its own ordered playback queue.
    public sealed class CombatEventStream
    {
        public event Action<CombatEvent> Published;
        public void Publish(CombatEvent message)
        {
            if (message == null) throw new ArgumentNullException("message");
            if (Published != null) Published(message);
        }
    }
}
