namespace ARCardPrototype
{
    // Immutable snapshots: presentation never reads a future HP for an old event.
    public abstract class CombatEvent { }

    public sealed class GameResetEvent : CombatEvent { }

    public sealed class AttackDeclaredEvent : CombatEvent
    {
        public int SourceId { get; private set; }
        public int TargetId { get; private set; }
        public AttackDeclaredEvent(int sourceId, int targetId)
        { SourceId = sourceId; TargetId = targetId; }
    }

    public sealed class DodgeEvent : CombatEvent
    {
        public int PlayerId { get; private set; }
        public DodgeEvent(int playerId) { PlayerId = playerId; }
    }

    // Result of an already committed rules operation, never a request to mutate HP.
    public sealed class DamageEvent : CombatEvent
    {
        public int SourceId { get; private set; }
        public int TargetId { get; private set; }
        public int OldHealth { get; private set; }
        public int NewHealth { get; private set; }
        public int MaxHealth { get; private set; }
        public int Amount { get { return OldHealth - NewHealth; } }
        public DamageEvent(int sourceId, int targetId, int oldHealth, int newHealth, int maxHealth)
        {
            SourceId = sourceId; TargetId = targetId;
            OldHealth = oldHealth; NewHealth = newHealth; MaxHealth = maxHealth;
        }
    }

    public sealed class HealEvent : CombatEvent
    {
        public int PlayerId { get; private set; }
        public int OldHealth { get; private set; }
        public int NewHealth { get; private set; }
        public int MaxHealth { get; private set; }
        public int Amount { get { return NewHealth - OldHealth; } }
        public HealEvent(int playerId, int oldHealth, int newHealth, int maxHealth)
        { PlayerId = playerId; OldHealth = oldHealth; NewHealth = newHealth; MaxHealth = maxHealth; }
    }
}
