using System;
using System.Collections.Generic;

namespace ARCardPrototype
{
    // Pure C# model, not a component to attach to a GameObject.
    public sealed class Player
    {
        private readonly List<Card> hand = new List<Card>();
        public int Id { get; private set; }
        public string Name { get; private set; }
        public int MaxHealth { get; private set; }
        public int Health { get; private set; }
        public bool IsAlive { get { return Health > 0; } }
        public IReadOnlyList<Card> Hand { get; private set; }

        internal Player(int id, string name, int maxHealth)
        {
            Id = id;
            Name = name;
            MaxHealth = maxHealth;
            Health = maxHealth;
            Hand = hand.AsReadOnly();
        }

        internal void AddCard(Card card) { hand.Add(card); }
        internal void RemoveCard(int index) { hand.RemoveAt(index); }
        internal void TakeDamage(int amount) { Health = Math.Max(0, Health - amount); }
        internal void Heal(int amount) { Health = Math.Min(MaxHealth, Health + amount); }
    }
}
