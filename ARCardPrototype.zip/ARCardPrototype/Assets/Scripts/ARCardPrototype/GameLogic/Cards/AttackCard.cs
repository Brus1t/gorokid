namespace ARCardPrototype
{
    public sealed class AttackCard : Card
    {
        public override CardType Type { get { return CardType.Attack; } }
        public override string Name { get { return "Attack / Sha"; } }
        public override string Description { get { return "Target opponent. Deal 1 damage unless dodged. Once per turn."; } }
    }
}
