namespace ARCardPrototype
{
    public enum CardType { Attack, Dodge, Peach }

    // Immutable card data. Rule validation and resolution belong to GameManager.
    public abstract class Card
    {
        public abstract CardType Type { get; }
        public abstract string Name { get; }
        public abstract string Description { get; }
    }
}
