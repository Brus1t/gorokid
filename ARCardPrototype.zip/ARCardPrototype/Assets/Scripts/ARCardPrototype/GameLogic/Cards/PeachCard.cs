namespace ARCardPrototype
{
    public sealed class PeachCard : Card
    {
        public override CardType Type { get { return CardType.Peach; } }
        public override string Name { get { return "Peach / Tao"; } }
        public override string Description { get { return "During your turn, recover 1 HP. Self only."; } }
    }
}
