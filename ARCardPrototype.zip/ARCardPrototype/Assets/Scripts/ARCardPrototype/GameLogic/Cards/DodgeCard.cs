namespace ARCardPrototype
{
    public sealed class DodgeCard : Card
    {
        public override CardType Type { get { return CardType.Dodge; } }
        public override string Name { get { return "Dodge / Shan"; } }
        public override string Description { get { return "Respond to an Attack to prevent its damage."; } }
    }
}
