namespace ARCardPrototype
{
    public sealed class TurnManager
    {
        public int CurrentPlayerId { get; private set; }
        public int TurnNumber { get; private set; }
        public bool AttackUsed { get; private set; }

        internal void Reset()
        {
            CurrentPlayerId = 0;
            TurnNumber = 1;
            AttackUsed = false;
        }

        internal void MarkAttackUsed() { AttackUsed = true; }

        internal void Advance()
        {
            CurrentPlayerId = 1 - CurrentPlayerId;
            TurnNumber++;
            AttackUsed = false;
        }
    }
}
