namespace ARCardPrototype
{
    // The same policy drives highlights and authoritative confirmation.
    public static class TargetingRules
    {
        public static bool Allows(CardType type, int actorId, int targetId)
        {
            if (actorId < 0 || actorId > 1 || targetId < 0 || targetId > 1) return false;
            if (type == CardType.Attack) return actorId != targetId;
            if (type == CardType.Peach) return actorId == targetId;
            return false;
        }
    }
}
