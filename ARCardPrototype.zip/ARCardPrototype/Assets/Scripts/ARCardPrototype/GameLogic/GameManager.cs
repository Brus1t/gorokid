using System;
using System.Collections.Generic;

namespace ARCardPrototype
{
    public enum GamePhase { Playing, AwaitingDodge, GameOver }

    // All game decisions live here. No Unity, keyboard or Rokid dependencies.
    public sealed class GameManager
    {
        private readonly Player[] players = new Player[2];
        private readonly List<string> history = new List<string>();
        private readonly int seed;
        private Random random;
        private int defenderId = -1;

        public event Action Changed;
        public event Action<string> Logged;
        public CombatEventStream Events { get; private set; }
        public IReadOnlyList<Player> Players { get; private set; }
        public IReadOnlyList<string> History { get; private set; }
        public TurnManager Turns { get; private set; }
        public GamePhase Phase { get; private set; }
        public int SelectedCardIndex { get; private set; }
        public int SelectedTargetId { get; private set; }
        public int WinnerId { get; private set; }
        public Player CurrentPlayer { get { return players[Turns.CurrentPlayerId]; } }
        public Player ActingPlayer
        {
            get { return players[Phase == GamePhase.AwaitingDodge ? defenderId : Turns.CurrentPlayerId]; }
        }

        public GameManager(int randomSeed = 303)
        {
            seed = randomSeed;
            Players = Array.AsReadOnly(players);
            History = history.AsReadOnly();
            Turns = new TurnManager();
            Events = new CombatEventStream();
            Restart();
        }

        public void Restart()
        {
            random = new Random(seed);
            history.Clear();
            for (int i = 0; i < players.Length; i++)
            {
                players[i] = new Player(i, "Player " + (i + 1), 4);
                players[i].AddCard(new AttackCard());
                players[i].AddCard(new DodgeCard());
                players[i].AddCard(new PeachCard());
                players[i].AddCard(new AttackCard());
            }
            Turns.Reset();
            WinnerId = -1;
            defenderId = -1;
            Phase = GamePhase.Playing;
            ClearSelection();
            Log("New game. Both players start at 4 HP with Attack, Dodge, Peach, Attack.");
            BeginTurn();
            Events.Publish(new GameResetEvent());
            Notify();
        }

        public bool SelectCard(int index)
        {
            if (Phase == GamePhase.GameOver) return Reject("Game over. Restart to play again.");
            if (index < 0 || index >= ActingPlayer.Hand.Count) return Reject("Invalid hand slot.");
            SelectedCardIndex = index;
            // Do not carry a previous card's target to a newly selected card.
            SelectedTargetId = ActingPlayer.Hand[index].Type == CardType.Peach ? ActingPlayer.Id : -1;
            Notify();
            return true;
        }

        public bool SelectPlayer(int playerId)
        {
            if (Phase != GamePhase.Playing) return Reject("Targets can only be selected during the play phase.");
            if (playerId < 0 || playerId >= players.Length) return Reject("Invalid player.");
            SelectedTargetId = playerId;
            Notify();
            return true;
        }

        public bool Confirm()
        {
            if (Phase == GamePhase.GameOver) return Reject("Game over. Restart to play again.");
            Player actor = ActingPlayer;
            if (SelectedCardIndex < 0 || SelectedCardIndex >= actor.Hand.Count)
                return Reject("Select a card first.");
            Card card = actor.Hand[SelectedCardIndex];

            if (Phase == GamePhase.AwaitingDodge)
            {
                if (card.Type != CardType.Dodge) return Reject("Only Dodge can respond. Use Take damage to pass.");
                actor.RemoveCard(SelectedCardIndex);
                Log(actor.Name + " played Dodge. No damage.");
                FinishResponse();
                Events.Publish(new DodgeEvent(actor.Id));
                Notify();
                return true;
            }

            switch (card.Type)
            {
                case CardType.Attack:
                    if (Turns.AttackUsed) return Reject("Only one Attack per turn.");
                    if (SelectedTargetId < 0) return Reject("Select the opponent as target first.");
                    if (!TargetingRules.Allows(card.Type, actor.Id, SelectedTargetId)) return Reject("You cannot attack yourself.");
                    actor.RemoveCard(SelectedCardIndex);
                    Turns.MarkAttackUsed();
                    defenderId = SelectedTargetId;
                    Phase = GamePhase.AwaitingDodge;
                    ClearSelection();
                    Log(actor.Name + " attacked " + players[defenderId].Name + ". Defender: play Dodge or Take damage.");
                    Events.Publish(new AttackDeclaredEvent(actor.Id, defenderId));
                    break;
                case CardType.Peach:
                    if (!TargetingRules.Allows(card.Type, actor.Id, SelectedTargetId)) return Reject("Peach must target yourself.");
                    if (actor.Health == actor.MaxHealth) return Reject("Already at full HP. Peach was not consumed.");
                    actor.RemoveCard(SelectedCardIndex);
                    int healthBeforeHeal = actor.Health;
                    actor.Heal(1);
                    ClearSelection();
                    Log(actor.Name + " played Peach and recovered 1 HP.");
                    Events.Publish(new HealEvent(actor.Id, healthBeforeHeal, actor.Health, actor.MaxHealth));
                    break;
                case CardType.Dodge:
                    return Reject("Dodge is a response card; wait until you are attacked.");
            }
            Notify();
            return true;
        }

        public bool SkipResponse()
        {
            if (Phase != GamePhase.AwaitingDodge) return Reject("No Attack is waiting for a response.");
            Player defender = players[defenderId];
            int healthBeforeDamage = defender.Health;
            defender.TakeDamage(1);
            Log(defender.Name + " took 1 damage. HP: " + defender.Health + "/" + defender.MaxHealth);
            if (!defender.IsAlive)
            {
                WinnerId = Turns.CurrentPlayerId;
                Phase = GamePhase.GameOver;
                defenderId = -1;
                ClearSelection();
                Log(players[WinnerId].Name + " wins!");
            }
            else FinishResponse();
            Events.Publish(new DamageEvent(CurrentPlayer.Id, defender.Id, healthBeforeDamage, defender.Health, defender.MaxHealth));
            Notify();
            return true;
        }

        public bool Cancel()
        {
            if (Phase == GamePhase.GameOver) return Reject("Game over.");
            ClearSelection();
            // Cancel only clears selection: it never cancels an already played Attack.
            Notify();
            return true;
        }

        public bool EndTurn()
        {
            if (Phase != GamePhase.Playing) return Reject("Resolve the Attack before ending the turn, or restart after game over.");
            Player player = CurrentPlayer;
            // Simplified discard phase: discard from the end until hand count <= HP.
            while (player.Hand.Count > player.Health)
            {
                int last = player.Hand.Count - 1;
                Log(player.Name + " discarded " + player.Hand[last].Name + " (hand limit = HP).");
                player.RemoveCard(last);
            }
            Turns.Advance();
            ClearSelection();
            BeginTurn();
            Notify();
            return true;
        }

        private void BeginTurn()
        {
            // Infinite generated supply for the prototype; no physical deck/shuffle yet.
            for (int i = 0; i < 2; i++)
            {
                int roll = random.Next(100);
                Card card;
                if (roll < 50) card = new AttackCard();
                else if (roll < 80) card = new DodgeCard();
                else card = new PeachCard();
                CurrentPlayer.AddCard(card);
            }
            Log("Turn " + Turns.TurnNumber + ": " + CurrentPlayer.Name + " drew 2 cards.");
        }

        private void FinishResponse()
        {
            Phase = GamePhase.Playing;
            defenderId = -1;
            ClearSelection();
            Log(CurrentPlayer.Name + " may continue playing or end the turn.");
        }

        private void ClearSelection() { SelectedCardIndex = -1; SelectedTargetId = -1; }
        private void Notify() { if (Changed != null) Changed(); }
        private bool Reject(string message) { Log(message); Notify(); return false; }
        private void Log(string message)
        {
            history.Add(message);
            if (history.Count > 60) history.RemoveAt(0);
            if (Logged != null) Logged(message);
        }
    }
}
