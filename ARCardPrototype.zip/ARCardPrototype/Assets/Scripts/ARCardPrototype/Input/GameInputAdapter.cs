using UnityEngine;

namespace ARCardPrototype
{
    public abstract class GameInputAdapter : MonoBehaviour, IGameInput
    {
        protected GameManager Game { get; private set; }
        public void Initialize(GameManager game) { Game = game; }
        public System.Func<bool> IsBlocked { get; set; }
        protected bool CanSend { get { return isActiveAndEnabled && Game != null && (IsBlocked == null || !IsBlocked()); } }
        public void SelectCard(int handIndex) { if (CanSend) Game.SelectCard(handIndex); }
        public void SelectPlayer(int playerId) { if (CanSend) Game.SelectPlayer(playerId); }
        public void Confirm() { if (CanSend) Game.Confirm(); }
        public void Cancel() { if (CanSend) Game.Cancel(); }
        public void EndTurn() { if (CanSend) Game.EndTurn(); }
        public void SkipResponse() { if (CanSend) Game.SkipResponse(); }
    }
}
