namespace ARCardPrototype
{
    // Intentionally no SDK reference, hardware polling or invented Rokid API.
    public sealed class RokidInput : GameInputAdapter
    {
        // TODO: After confirming the device and SDK, subscribe/unsubscribe to its
        // real callbacks in OnEnable/OnDisable (or SDK-specific lifecycle).
        // TODO: Map a hit on a player anchor to SelectPlayer(0 or 1).
        // TODO: Map card selection to SelectCard(zeroBasedHandIndex).
        // TODO: Map confirmed gestures/voice commands to the inherited semantic
        // methods: Confirm(), Cancel(), EndTurn(), SkipResponse().
        // TODO: Marshal background callbacks to Unity's main thread, and debounce
        // repeated gesture/voice detections before forwarding a command.
        // Nothing in this shell assumes the device supports any given capability.
    }
}
