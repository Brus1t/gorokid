namespace ARCardPrototype
{
    // Semantic commands shared by desktop UI, keyboard and future hardware.
    // All methods must be called on the Unity main thread.
    public interface IGameInput
    {
        void SelectCard(int handIndex);
        void SelectPlayer(int playerId);
        void Confirm();
        void Cancel();
        void EndTurn();
        void SkipResponse();
    }
}
