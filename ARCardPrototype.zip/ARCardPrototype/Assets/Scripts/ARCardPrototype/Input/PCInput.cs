using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace ARCardPrototype
{
    public sealed class PCInput : GameInputAdapter
    {
        private void Update()
        {
            if (!CanSend) return;
            // Prefer the new backend when Both is selected: never dispatch twice.
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            if (keyboard == null) return;
            for (int i = 0; i < 9; i++)
                if (keyboard[(Key)((int)Key.Digit1 + i)].wasPressedThisFrame) SelectCard(i);
            if (keyboard.qKey.wasPressedThisFrame) SelectPlayer(0);
            if (keyboard.wKey.wasPressedThisFrame) SelectPlayer(1);
            // At most one state-changing action in a frame.
            if (keyboard.enterKey.wasPressedThisFrame) Confirm();
            else if (keyboard.escapeKey.wasPressedThisFrame) Cancel();
            else if (keyboard.eKey.wasPressedThisFrame) EndTurn();
            else if (keyboard.sKey.wasPressedThisFrame) SkipResponse();
#elif ENABLE_LEGACY_INPUT_MANAGER
            for (int i = 0; i < 9; i++)
                if (UnityEngine.Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha1 + i))) SelectCard(i);
            if (UnityEngine.Input.GetKeyDown(KeyCode.Q)) SelectPlayer(0);
            if (UnityEngine.Input.GetKeyDown(KeyCode.W)) SelectPlayer(1);
            if (UnityEngine.Input.GetKeyDown(KeyCode.Return)) Confirm();
            else if (UnityEngine.Input.GetKeyDown(KeyCode.Escape)) Cancel();
            else if (UnityEngine.Input.GetKeyDown(KeyCode.E)) EndTurn();
            else if (UnityEngine.Input.GetKeyDown(KeyCode.S)) SkipResponse();
#endif
        }
    }
}
