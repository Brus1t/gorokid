using UnityEngine;

namespace ARCardPrototype
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(PCInput), typeof(TabletopView), typeof(TabletopPresenter))]
    [RequireComponent(typeof(DemoDirector), typeof(SynthCombatAudio))]
    public sealed class GameBootstrap : MonoBehaviour
    {
        [SerializeField] private int randomSeed = 303;
        public GameManager Game { get; private set; }

        private void Awake()
        {
            Game = new GameManager(randomSeed);
            Game.Logged += WriteLog;
            foreach (string message in Game.History) WriteLog(message);
            PCInput desktop = GetComponent<PCInput>();
            desktop.Initialize(Game);
            TabletopPresenter presenter = GetComponent<TabletopPresenter>();
            presenter.Initialize(Game);
            DemoDirector demo = GetComponent<DemoDirector>();
            demo.Initialize(Game, presenter);
            desktop.IsBlocked = () => presenter.IsBusy || demo.IsRunning;
            SynthCombatAudio sound = GetComponent<SynthCombatAudio>();
            sound.Initialize(presenter);
            GetComponent<TabletopView>().Initialize(Game, desktop, presenter, demo, sound);
        }

        private void OnDestroy()
        {
            if (Game != null) Game.Logged -= WriteLog;
        }

        private void WriteLog(string message) { Debug.Log("[ARCardPrototype] " + message, this); }
    }
}
