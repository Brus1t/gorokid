using System.Collections.Generic;
using UnityEngine;

namespace ARCardPrototype
{
    // All geometry and materials are generated here. No third-party art assets.
    public sealed class VisualFactory
    {
        private readonly List<Material> materials = new List<Material>();
        private readonly Font font;

        public VisualFactory()
        {
#if UNITY_2023_1_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        public Material Material(Color color)
        {
            // Resources makes this small original shader available in player builds.
            Shader shader = Resources.Load<Shader>("PrototypeUnlit");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            var material = new Material(shader);
            SetColor(material, color);
            materials.Add(material);
            return material;
        }

        public static void SetColor(Material material, Color color)
        {
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
        }

        public GameObject Shape(string name, PrimitiveType type, Transform parent, Vector3 position, Vector3 scale, Material material)
        {
            GameObject obj = GameObject.CreatePrimitive(type);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = position;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = material;
            Collider collider = obj.GetComponent<Collider>();
            if (collider != null) Object.Destroy(collider);
            return obj;
        }

        public TextMesh Text(string name, Transform parent, Vector3 position, string value, float size, Color color)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = position;
            var text = obj.AddComponent<TextMesh>();
            text.font = font;
            text.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            text.text = value;
            text.fontSize = 64;
            text.characterSize = size;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = color;
            return text;
        }

        public void Dispose()
        {
            foreach (Material material in materials) Object.Destroy(material);
            materials.Clear();
        }
    }
}
