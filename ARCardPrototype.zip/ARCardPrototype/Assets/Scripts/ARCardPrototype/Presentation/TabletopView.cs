using UnityEngine;

namespace ARCardPrototype
{
    // Full-screen PC table. Its only rule-changing dependency is IGameInput.
    // AR can replace this surface while keeping GameLogic and CombatEvents.
    public sealed class TabletopView : MonoBehaviour
    {
        private GameManager game;
        private IGameInput input;
        private TabletopPresenter visual;
        private DemoDirector demo;
        private SynthCombatAudio audioView;
        private Texture2D artwork, shade;
        private Font bodyFont, titleFont;
        private Vector2 mouse;
        private int hovered = -1;
        private readonly float[] lifts = new float[16];
        private string lastAction = "双方各 4 点体力。选择手牌，开始你的回合。";
        private bool subscribed;
        private static readonly string[] Names = { "青岚", "赤曜" };
        private static readonly Color Muted = new Color(0.57f, 0.62f, 0.60f);
        private static readonly Color White = new Color(0.94f, 0.92f, 0.85f);

        public void Initialize(GameManager manager, IGameInput commands, TabletopPresenter presenter,
            DemoDirector director, SynthCombatAudio sound)
        {
            game = manager; input = commands; visual = presenter; demo = director; audioView = sound;
            artwork = Resources.Load<Texture2D>("InkBattlefield");
            bodyFont = Font.CreateDynamicFontFromOSFont(new[] { "Microsoft YaHei", "Noto Sans CJK SC", "Arial" }, 24);
            titleFont = Font.CreateDynamicFontFromOSFont(new[] { "KaiTi", "SimSun", "Microsoft YaHei", "Arial" }, 64);
            shade = new Texture2D(1, 64, TextureFormat.RGBA32, false);
            shade.wrapMode = TextureWrapMode.Clamp;
            for (int i = 0; i < 64; i++) shade.SetPixel(0, i, new Color(0.015f, 0.03f, 0.032f, 1f - (float)i / 63));
            shade.Apply(); Subscribe();
        }
        private void Subscribe()
        { if (visual != null && !subscribed && isActiveAndEnabled) { visual.Began += OnPresented; subscribed = true; } }
        private void OnEnable() { Subscribe(); }
        private void OnDisable()
        { if (subscribed) visual.Began -= OnPresented; subscribed = false; }
        private void OnDestroy()
        { if (shade != null) Destroy(shade); if (bodyFont != null) Destroy(bodyFont); if (titleFont != null) Destroy(titleFont); }
        private void OnPresented(CombatEvent message)
        {
            var hit = message as DamageEvent;
            var attack = message as AttackDeclaredEvent;
            var heal = message as HealEvent;
            var dodge = message as DodgeEvent;
            if (message is GameResetEvent) lastAction = "新一局 · 双方各 4 点体力，青岚先手。";
            if (attack != null) lastAction = Names[attack.SourceId] + " 对 " + Names[attack.TargetId] + " 打出了「杀」。";
            if (hit != null) lastAction = Names[hit.TargetId] + " 受到 " + hit.Amount + " 点伤害。";
            if (heal != null) lastAction = Names[heal.PlayerId] + " 使用「桃」，恢复 1 点体力。";
            if (dodge != null) lastAction = Names[dodge.PlayerId] + " 打出「闪」，抵消攻击。";
        }
        private bool Locked { get { return visual.IsBusy || demo.IsRunning; } }
        private void Update()
        {
            if (game == null) return;
            for (int i = 0; i < lifts.Length; i++)
            {
                float desired = i == game.SelectedCardIndex ? 28 : i == hovered ? 15 : 0;
                lifts[i] = Mathf.Lerp(lifts[i], desired, 1 - Mathf.Exp(-14 * Time.unscaledDeltaTime));
            }
        }
        private void OnGUI()
        {
            if (game == null) return;
            Matrix4x4 oldMatrix = GUI.matrix; Color oldColor = GUI.color;
            bool oldEnabled = GUI.enabled;
            try
            {
                float scale = Mathf.Min(Screen.width / 1600f, Screen.height / 900f);
                Vector2 offset = new Vector2((Screen.width - 1600 * scale) / 2, (Screen.height - 900 * scale) / 2);
                mouse = (Event.current.mousePosition - offset) / scale;
                GUI.color = Color.white;
                InkDraw.Fill(new Rect(0, 0, Screen.width, Screen.height), Color.black);
                GUI.matrix = Matrix4x4.TRS(new Vector3(offset.x, offset.y, 0), Quaternion.identity, Vector3.one * scale);
                InkDraw.Fill(new Rect(0, 0, 1600, 900), InkDraw.Ink);
                if (artwork != null) GUI.DrawTexture(new Rect(0, 0, 1600, 900), artwork, ScaleMode.StretchToFill);
                // Keep the artwork visible, with legible interface zones.
                GUI.DrawTexture(new Rect(0, 540, 1600, 360), shade);
                InkDraw.Fill(new Rect(0, 0, 1600, 106), new Color(0.018f, 0.035f, 0.04f, 0.85f));
                DrawHeader();
                DrawSeat(0); DrawSeat(1);
                DrawOpponentHand();
                DrawCenter();
                DrawHand();
                DrawActions();
                DrawEffects();
                InkDraw.Line(new Vector2(42, 867), new Vector2(1558, 867), new Color(0.79f, 0.65f, 0.39f, 0.22f));
                InkDraw.Text(new Rect(44, 872, 760, 24), lastAction, 13, Muted, bodyFont);
                InkDraw.Text(new Rect(900, 872, 657, 24), "1–9 选牌   Q / W 选人   Enter 确认   E 结束回合", 12, Muted, bodyFont, TextAnchor.MiddleRight);
            }
            finally { GUI.matrix = oldMatrix; GUI.color = oldColor; GUI.enabled = oldEnabled; }
        }
        private void DrawHeader()
        {
            InkDraw.Diamond(new Vector2(54, 50), 17, InkDraw.Gold);
            InkDraw.Text(new Rect(79, 15, 160, 64), "墨 局", 45, InkDraw.Paper, titleFont);
            InkDraw.Text(new Rect(82, 72, 300, 19), "M O J U   /   双 人 策 略 桌 游", 11, InkDraw.Gold, bodyFont);
            InkDraw.Line(new Vector2(310, 28), new Vector2(310, 77), new Color(1, 1, 1, 0.15f));
            InkDraw.Text(new Rect(330, 31, 230, 25), "山河为局 · 一牌定势", 17, White, bodyFont);
            InkDraw.Text(new Rect(331, 61, 230, 20), "本地双人 / 自由对弈", 12, Muted, bodyFont);
            InkDraw.Border(new Rect(656, 29, 260, 47), new Color(0.79f, 0.65f, 0.39f, 0.5f));
            InkDraw.Text(new Rect(657, 30, 258, 45), "第 " + game.Turns.TurnNumber.ToString("00") + " 回合  ·  " + Names[game.CurrentPlayer.Id], 20, InkDraw.Paper, titleFont, TextAnchor.MiddleCenter);
            if (Button(new Rect(1068, 33, 115, 43), audioView.Muted ? "音效  关" : "音效  开", false, true))
            { audioView.Muted = !audioView.Muted; GUIUtility.ExitGUI(); }
            if (Button(new Rect(1200, 33, 225, 43), demo.IsRunning ? "■  停止演示" : "▶  一键演示", true, true))
            { if (demo.IsRunning) demo.Stop(); else demo.Play(); GUIUtility.ExitGUI(); }
            if (Button(new Rect(1442, 33, 115, 43), "重新开局", false, !demo.IsRunning))
            { game.Restart(); GUIUtility.ExitGUI(); }
        }
        private void DrawSeat(int id)
        {
            float x = id == 0 ? 44 : 1268;
            Color color = id == 0 ? InkDraw.Jade : InkDraw.Red;
            Rect hitbox = new Rect(x, 137, 288, 412);
            bool selected = game.SelectedTargetId == id;
            bool legal = game.Phase == GamePhase.Playing && game.SelectedCardIndex >= 0 &&
                TargetingRules.Allows(game.ActingPlayer.Hand[game.SelectedCardIndex].Type, game.ActingPlayer.Id, id);
            var hit = visual.Active as DamageEvent;
            float shake = hit != null && hit.TargetId == id && visual.Age < 0.35f ?
                Mathf.Sin(visual.Age * 95) * 10 * (1 - visual.Age / 0.35f) : 0;
            x += shake;
            if (Mathf.Abs(shake) > 0.01f && artwork != null)
            {
                float baseX = id == 0 ? 44 : 1268;
                InkDraw.Fill(new Rect(baseX - 10, 139, 308, 284), new Color(0.02f, 0.04f, 0.04f));
                GUI.DrawTextureWithTexCoords(new Rect(x, 139, 288, 284), artwork,
                    new Rect(baseX / 1600f, 1 - 423f / 900, 288f / 1600, 284f / 900));
            }
            if (hit != null && hit.TargetId == id && visual.Age < 0.22f)
                InkDraw.Fill(new Rect(x, 139, 288, 290), new Color(1, 0.8f, 0.58f, 0.2f * Mathf.Abs(Mathf.Sin(visual.Age * 60))));
            // Broken corner brackets leave the illustrated portrait unobstructed.
            Color frame = selected ? InkDraw.Gold : legal ? color : new Color(color.r, color.g, color.b, 0.4f);
            float length = selected ? 48 : 26;
            foreach (float sx in new[] { x, x + 288 })
            {
                float sign = sx == x ? 1 : -1;
                InkDraw.Line(new Vector2(sx, 139), new Vector2(sx + sign * length, 139), frame, 2);
                InkDraw.Line(new Vector2(sx, 139), new Vector2(sx, 164), frame, 2);
            }
            if (selected || legal && hitbox.Contains(mouse))
                InkDraw.Border(new Rect(x - 4, 134, 296, 414), new Color(frame.r, frame.g, frame.b, 0.75f), 2);
            InkDraw.Fill(new Rect(x, 423, 288, 124), new Color(0.025f, 0.047f, 0.048f, 0.92f));
            InkDraw.Fill(new Rect(x, 423, 3, 124), color);
            InkDraw.Text(new Rect(x + 19, 428, 116, 50), Names[id], 34, InkDraw.Paper, titleFont);
            InkDraw.Text(new Rect(x + 174, 433, 94, 34), visual.HealthText[id] + " / 4", 26, White, bodyFont, TextAnchor.MiddleRight);
            InkDraw.Text(new Rect(x + 21, 476, 195, 19), (id == 0 ? "青 阵" : "赤 阵") + "   ·   PLAYER " + (id + 1), 11, color, bodyFont);
            Rect bar = new Rect(x + 21, 506, 246, 8);
            InkDraw.Fill(bar, new Color(0.1f, 0.17f, 0.17f));
            InkDraw.Fill(new Rect(bar.x, bar.y, bar.width * visual.HealthShadow[id] / 4, bar.height), InkDraw.Gold);
            InkDraw.Fill(new Rect(bar.x, bar.y, bar.width * visual.Health[id] / 4, bar.height), color);
            for (int i = 1; i < 4; i++) InkDraw.Fill(new Rect(bar.x + bar.width * i / 4 - 1, bar.y, 2, 8), InkDraw.Ink);
            InkDraw.Text(new Rect(x + 20, 522, 248, 18), selected ? "◎ 已锁定目标" : game.ActingPlayer.Id == id ? "● 当前操作者" : "手牌 " + game.Players[id].Hand.Count + " 张", 11, selected ? InkDraw.Gold : Muted, bodyFont);
            if (legal && !Locked && GUI.Button(hitbox, GUIContent.none, GUIStyle.none))
            { input.SelectPlayer(id); GUIUtility.ExitGUI(); }
        }
        private void DrawOpponentHand()
        {
            int count = game.Players[1 - game.ActingPlayer.Id].Hand.Count;
            float left = 800 - (count * 23 + 15) / 2f;
            for (int i = 0; i < count; i++)
            {
                Rect card = new Rect(left + i * 23, 125, 34, 46);
                InkDraw.Fill(card, new Color(0.05f, 0.11f, 0.12f, 0.95f));
                InkDraw.Border(card, new Color(0.79f, 0.65f, 0.39f, 0.6f));
                InkDraw.Diamond(card.center, 9, new Color(0.79f, 0.65f, 0.39f, 0.55f));
            }
            InkDraw.Text(new Rect(670, 175, 260, 21), "对方手牌  /  " + count, 11, InkDraw.Paper, bodyFont, TextAnchor.MiddleCenter);
        }
        private void DrawCenter()
        {
            string title;
            string hint;
            if (game.Phase == GamePhase.GameOver) { title = Names[game.WinnerId] + " 获胜"; hint = "本局结束 · 重新开局再战"; }
            else if (visual.Active is AttackDeclaredEvent) { title = "杀 · 出鞘"; hint = "攻击正在结算"; }
            else if (visual.Active is DamageEvent) { title = "命中"; hint = "受到 1 点伤害"; }
            else if (visual.Active is DodgeEvent) { title = "闪 · 化解"; hint = "此次攻击被抵消"; }
            else if (visual.Active is HealEvent) { title = "桃 · 回春"; hint = "恢复 1 点体力"; }
            else if (game.Phase == GamePhase.AwaitingDodge) { title = Names[game.ActingPlayer.Id] + " · 请响应"; hint = "打出「闪」，或选择承受伤害"; }
            else { title = Names[game.CurrentPlayer.Id] + " · 出牌阶段"; hint = game.SelectedCardIndex >= 0 ? "选择目标，再确认出牌" : "选择一张手牌，或结束本回合"; }
            InkDraw.Fill(new Rect(536, 213, 528, 75), new Color(0.03f, 0.045f, 0.04f, 0.7f));
            InkDraw.Text(new Rect(546, 211, 508, 43), title, 30, InkDraw.Paper, titleFont, TextAnchor.MiddleCenter);
            InkDraw.Text(new Rect(546, 253, 508, 27), hint, 13, Muted, bodyFont, TextAnchor.MiddleCenter);
            float time = Time.unscaledTime;
            InkDraw.Ring(new Vector2(800, 413), 111, new Color(0.79f, 0.65f, 0.39f, 0.18f), 1);
            InkDraw.Ring(new Vector2(800, 413), 119, new Color(0.79f, 0.65f, 0.39f, 0.35f), 1, time * 0.12f, 0.2f);
            InkDraw.Ring(new Vector2(800, 413), 119, new Color(0.79f, 0.65f, 0.39f, 0.35f), 1, time * 0.12f + Mathf.PI, 0.2f);
            if (!visual.IsBusy)
            {
                InkDraw.Text(new Rect(727, 363, 146, 77), "对 弈", 41, new Color(0.91f, 0.86f, 0.74f, 0.72f), titleFont, TextAnchor.MiddleCenter);
                InkDraw.Text(new Rect(694, 448, 212, 24), "一 牌  ·  一 势", 11, InkDraw.Gold, bodyFont, TextAnchor.MiddleCenter);
            }
            string caption = demo.IsRunning ? demo.Caption : "";
            if (!string.IsNullOrEmpty(caption))
            {
                InkDraw.Fill(new Rect(442, 551, 716, 39), new Color(0.04f, 0.08f, 0.075f, 0.93f));
                InkDraw.Text(new Rect(456, 554, 688, 32), caption, 17, InkDraw.Paper, bodyFont, TextAnchor.MiddleCenter);
            }
        }
        private void DrawHand()
        {
            InkDraw.Text(new Rect(47, 649, 232, 42), "你的手牌", 30, InkDraw.Paper, titleFont);
            InkDraw.Text(new Rect(49, 696, 212, 27), Names[game.ActingPlayer.Id] + "  /  " + game.ActingPlayer.Hand.Count + " 张", 15, InkDraw.Gold, bodyFont);
            InkDraw.Line(new Vector2(49, 741), new Vector2(233, 741), new Color(0.79f, 0.65f, 0.39f, 0.3f));
            string help = game.Phase == GamePhase.AwaitingDodge ? "闪只能用于响应攻击。\n没有闪？可承受伤害。" : "杀：每回合一次\n桃：恢复自身 1 点体力";
            InkDraw.Text(new Rect(49, 758, 211, 63), help, 13, Muted, bodyFont);
            int count = game.ActingPlayer.Hand.Count;
            float spacing = Mathf.Min(148, 934f / Mathf.Max(1, count));
            float left = 800 - ((count - 1) * spacing + 132) / 2;
            hovered = -1;
            // Draw in index order; overlapping slot hitboxes use visible strip widths.
            for (int i = 0; i < count; i++)
            {
                float lift = i < lifts.Length ? lifts[i] : 0;
                Rect rect = new Rect(left + i * spacing, 651 - lift, 132, 195);
                Rect hit = new Rect(rect.x, rect.y, i == count - 1 ? rect.width : Mathf.Min(rect.width, spacing), rect.height);
                bool over = hit.Contains(mouse);
                if (over) hovered = i;
                bool selected = game.SelectedCardIndex == i;
                if (selected || over)
                {
                    InkDraw.Fill(new Rect(rect.x - 4, rect.y - 4, rect.width + 8, rect.height + 8), new Color(0.79f, 0.65f, 0.39f, selected ? 0.9f : 0.4f));
                    if (selected) InkDraw.Diamond(new Vector2(rect.center.x, rect.y - 13), 9, InkDraw.Gold);
                }
                DrawCard(rect, game.ActingPlayer.Hand[i].Type, i + 1);
                if (!Locked && game.Phase != GamePhase.GameOver && GUI.Button(hit, GUIContent.none, GUIStyle.none))
                { input.SelectCard(i); GUIUtility.ExitGUI(); }
            }
        }
        private void DrawCard(Rect rect, CardType type, int number)
        {
            Matrix4x4 old = GUI.matrix;
            GUI.matrix = old * Matrix4x4.TRS(new Vector3(rect.x, rect.y, 0), Quaternion.identity, new Vector3(rect.width / 132, rect.height / 195, 1));
            Color accent = type == CardType.Attack ? new Color(0.5f, 0.12f, 0.09f) : type == CardType.Dodge ? new Color(0.07f, 0.33f, 0.33f) : new Color(0.38f, 0.32f, 0.15f);
            InkDraw.Fill(new Rect(4, 7, 132, 195), new Color(0, 0, 0, 0.45f));
            InkDraw.Fill(new Rect(0, 0, 132, 195), InkDraw.Paper);
            InkDraw.Border(new Rect(5, 5, 122, 185), accent, 1);
            InkDraw.Fill(new Rect(0, 0, 132, 28), accent);
            string label = type == CardType.Attack ? "攻 击" : type == CardType.Dodge ? "响 应" : "恢 复";
            InkDraw.Text(new Rect(12, 2, 105, 24), label, 12, InkDraw.Paper, bodyFont, TextAnchor.MiddleCenter);
            InkDraw.Ring(new Vector2(66, 92), 40, new Color(accent.r, accent.g, accent.b, 0.22f));
            InkDraw.Diamond(new Vector2(66, 92), 55, new Color(accent.r, accent.g, accent.b, 0.05f));
            InkDraw.Text(new Rect(16, 36, 100, 107), type == CardType.Attack ? "杀" : type == CardType.Dodge ? "闪" : "桃", 74, accent, titleFont, TextAnchor.MiddleCenter);
            InkDraw.Text(new Rect(8, 135, 116, 21), type == CardType.Attack ? "SHA  /  ATTACK" : type == CardType.Dodge ? "SHAN  /  DODGE" : "TAO  /  HEAL", 9, accent, bodyFont, TextAnchor.MiddleCenter);
            InkDraw.Line(new Vector2(20, 162), new Vector2(112, 162), new Color(accent.r, accent.g, accent.b, 0.3f));
            InkDraw.Text(new Rect(9, 165, 113, 20), type == CardType.Attack ? "造成 1 点伤害" : type == CardType.Dodge ? "抵消一次杀" : "恢复 1 点体力", 11, accent, bodyFont, TextAnchor.MiddleCenter);
            if (number > 0) InkDraw.Text(new Rect(9, 30, 21, 22), number.ToString("00"), 10, accent, bodyFont);
            GUI.matrix = old;
        }
        private void DrawActions()
        {
            bool selected = game.SelectedCardIndex >= 0;
            CardType type = selected ? game.ActingPlayer.Hand[game.SelectedCardIndex].Type : CardType.Attack;
            bool confirm = selected && !Locked && game.Phase != GamePhase.GameOver;
            if (confirm)
            {
                if (game.Phase == GamePhase.AwaitingDodge) confirm = type == CardType.Dodge;
                else confirm = TargetingRules.Allows(type, game.ActingPlayer.Id, game.SelectedTargetId) &&
                    (type != CardType.Attack || !game.Turns.AttackUsed) &&
                    (type != CardType.Peach || game.ActingPlayer.Health < game.ActingPlayer.MaxHealth);
            }
            string title = !selected ? "先选择手牌" : type == CardType.Attack ? "确认出杀" : type == CardType.Dodge ? "打出闪" : "使用桃";
            InkDraw.Text(new Rect(1300, 612, 254, 25), Locked ? "正在演示 / 播放反馈" : "行 动", 12, InkDraw.Gold, bodyFont);
            if (Button(new Rect(1300, 651, 254, 52), title + "  ↗", true, confirm))
            { input.Confirm(); GUIUtility.ExitGUI(); }
            bool response = game.Phase == GamePhase.AwaitingDodge;
            if (Button(new Rect(1300, 718, 254, 44), response ? "承受伤害  −1" : "结束回合  →", false,
                !Locked && game.Phase != GamePhase.GameOver))
            { if (response) input.SkipResponse(); else input.EndTurn(); GUIUtility.ExitGUI(); }
            if (Button(new Rect(1300, 777, 254, 37), "取消选择", false, !Locked && selected))
            { input.Cancel(); GUIUtility.ExitGUI(); }
            InkDraw.Text(new Rect(1300, 828, 254, 19), "杀每回合限一次 · 闪仅响应", 11, Muted, bodyFont, TextAnchor.MiddleCenter);
        }
        private bool Button(Rect rect, string label, bool primary, bool enabled)
        {
            bool over = rect.Contains(mouse) && enabled;
            Color background = primary ? InkDraw.Gold : new Color(0.04f, 0.085f, 0.085f, 0.93f);
            if (!enabled) background = new Color(0.1f, 0.13f, 0.12f, 0.9f);
            else if (over) background = Color.Lerp(background, InkDraw.Paper, 0.15f);
            InkDraw.Fill(rect, background);
            InkDraw.Border(rect, new Color(0.79f, 0.65f, 0.39f, enabled ? 0.75f : 0.2f));
            InkDraw.Text(rect, label, 15, !enabled ? Muted : primary ? InkDraw.Ink : InkDraw.Paper, bodyFont, TextAnchor.MiddleCenter);
            return enabled && GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }
        private void DrawEffects()
        {
            float age = visual.Age;
            var attack = visual.Active as AttackDeclaredEvent;
            var damage = visual.Active as DamageEvent;
            var dodge = visual.Active as DodgeEvent;
            var heal = visual.Active as HealEvent;
            if (attack != null)
            {
                float fly = Mathf.SmoothStep(0, 1, age / 0.46f);
                if (age < 0.82f)
                {
                    Vector2 pos = Vector2.Lerp(new Vector2(734, 650), new Vector2(734, 316), fly);
                    Matrix4x4 old = GUI.matrix;
                    GUIUtility.RotateAroundPivot(Mathf.Lerp(-18, 0, fly), pos + new Vector2(66, 98));
                    DrawCard(new Rect(pos.x, pos.y, 132, 195), CardType.Attack, 0);
                    GUI.matrix = old;
                }
                if (age > 0.58f)
                {
                    Vector2 start = new Vector2(attack.SourceId == 0 ? 250 : 1350, 335);
                    Vector2 end = new Vector2(attack.TargetId == 0 ? 250 : 1350, 335);
                    float t = Mathf.Clamp01((age - 0.58f) / 0.7f);
                    Vector2 previous = start;
                    for (int i = 1; i <= 36; i++)
                    {
                        float u = t * i / 36;
                        Vector2 p = Vector2.Lerp(start, end, u) + Vector2.up * Mathf.Sin(u * Mathf.PI) * 65;
                        float alpha = i / 36f * (1 - Mathf.Clamp01((age - 1.2f) / 0.25f));
                        InkDraw.Line(previous, p, new Color(1, 0.5f, 0.15f, alpha * 0.16f), 24);
                        InkDraw.Line(previous, p, new Color(1, 0.78f, 0.38f, alpha * 0.8f), 5);
                        InkDraw.Line(previous, p, new Color(1, 0.94f, 0.76f, alpha), 1.5f);
                        previous = p;
                    }
                    InkDraw.Diamond(previous, 16, new Color(1, 0.9f, 0.6f, 1 - t * 0.5f));
                }
            }
            if (damage != null || dodge != null || heal != null)
            {
                int id = damage != null ? damage.TargetId : dodge != null ? dodge.PlayerId : heal.PlayerId;
                Vector2 center = new Vector2(id == 0 ? 225 : 1375, 330);
                Color color = damage != null ? InkDraw.Red : dodge != null ? new Color(0.5f, 0.85f, 0.96f) : InkDraw.Jade;
                float fade = 1 - Mathf.Clamp01((age - 0.55f) / 0.5f);
                InkDraw.Ring(center, 30 + age * 100, new Color(color.r, color.g, color.b, fade * 0.7f), 2, -age, dodge != null ? 0.9f : 1);
                if (dodge != null) InkDraw.Ring(center, 75, new Color(color.r, color.g, color.b, fade), 3, age * 3, 0.8f);
                for (int i = 0; i < 16; i++)
                {
                    float a = i * 2.39996f;
                    Vector2 p = center + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * (20 + age * (50 + i * 5));
                    InkDraw.Diamond(p, Mathf.Max(1, 5 - age * 3), new Color(color.r, color.g, color.b, fade));
                }
                if (damage != null && age < 0.5f)
                {
                    InkDraw.Line(center + new Vector2(-55, 63), center + new Vector2(62, -74), new Color(1, 0.87f, 0.67f, fade), 5);
                    InkDraw.Line(center + new Vector2(-35, -51), center + new Vector2(51, 41), new Color(1, 0.87f, 0.67f, fade * 0.7f), 3);
                }
                string text = damage != null ? "−" + damage.Amount : dodge != null ? "闪" : "+" + heal.Amount;
                InkDraw.Text(new Rect(center.x - 80, center.y - 65 - age * 54, 160, 110), text, dodge != null ? 73 : 62,
                    new Color(color.r, color.g, color.b, fade), titleFont, TextAnchor.MiddleCenter, FontStyle.Bold);
            }
        }
    }
}
