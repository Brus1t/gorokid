using UnityEngine;

namespace ARCardPrototype
{
    // Original short synthesized cues. No samples from existing games.
    [RequireComponent(typeof(AudioSource))]
    public sealed class SynthCombatAudio : MonoBehaviour
    {
        private TabletopPresenter presenter;
        private AudioSource source;
        private AudioClip attack, damage, dodge, heal;
        private bool subscribed;
        public bool Muted { get; set; }
        public void Initialize(TabletopPresenter visual)
        {
            presenter = visual; source = GetComponent<AudioSource>();
            source.playOnAwake = false; source.spatialBlend = 0; source.volume = 0.25f;
            attack = CreateTone("Card swipe", 0.35f, 250, 75, 0.5f);
            damage = CreateTone("Impact", 0.22f, 140, 45, 0.65f);
            dodge = CreateTone("Deflect", 0.3f, 1000, 1600, 0.08f);
            heal = CreateTone("Restore", 0.55f, 520, 780, 0);
            Subscribe();
        }
        private AudioClip CreateTone(string name, float seconds, float start, float end, float noise)
        {
            const int rate = 24000;
            var samples = new float[(int)(seconds * rate)];
            var random = new System.Random(303);
            float phase = 0;
            for (int i = 0; i < samples.Length; i++)
            {
                float t = (float)i / samples.Length;
                phase += Mathf.Lerp(start, end, t) * 2 * Mathf.PI / rate;
                float envelope = Mathf.Sin(t * Mathf.PI) * Mathf.Exp(-3 * t);
                samples[i] = (Mathf.Sin(phase) * (1 - noise) + ((float)random.NextDouble() * 2 - 1) * noise) * envelope * 0.55f;
            }
            AudioClip clip = AudioClip.Create(name, samples.Length, 1, rate, false);
            clip.SetData(samples, 0); return clip;
        }
        private void Subscribe()
        { if (presenter != null && !subscribed && isActiveAndEnabled) { presenter.Began += Play; subscribed = true; } }
        private void OnEnable() { Subscribe(); }
        private void OnDisable()
        {
            if (subscribed) presenter.Began -= Play;
            subscribed = false; if (source != null) source.Stop();
        }
        private void Play(CombatEvent message)
        {
            if (message is GameResetEvent) { source.Stop(); return; }
            if (Muted) return;
            AudioClip clip = message is AttackDeclaredEvent ? attack : message is DamageEvent ? damage :
                message is DodgeEvent ? dodge : message is HealEvent ? heal : null;
            if (clip != null) source.PlayOneShot(clip);
        }
        private void OnDestroy()
        { if (attack != null) Destroy(attack); if (damage != null) Destroy(damage); if (dodge != null) Destroy(dodge); if (heal != null) Destroy(heal); }
    }
}
