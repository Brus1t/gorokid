using UnityEngine;

namespace ARCardPrototype
{
    public sealed class AttackVfx : PooledEffect
    {
        public const float Duration = 0.35f;
        private Vector3 start, destination;
        private float age;
        private LineRenderer trail;

        public void Initialize(VisualFactory factory)
        {
            Material material = factory.Material(new Color(1f, 0.8f, 0.22f));
            factory.Shape("Projectile", PrimitiveType.Sphere, transform, Vector3.zero, Vector3.one * 0.22f, material);
            trail = gameObject.AddComponent<LineRenderer>();
            trail.sharedMaterial = material;
            trail.positionCount = 2;
            trail.startWidth = 0.025f;
            trail.endWidth = 0.09f;
            trail.useWorldSpace = true;
        }
        public void Launch(Vector3 from, Vector3 to)
        {
            start = from; destination = to; age = 0;
            transform.position = from;
            trail.SetPosition(0, from); trail.SetPosition(1, from);
        }
        private void Update()
        {
            age += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(age / Duration);
            Vector3 point = Vector3.Lerp(start, destination, t) + Vector3.up * Mathf.Sin(t * Mathf.PI) * 0.4f;
            transform.position = point;
            trail.SetPosition(0, Vector3.Lerp(start, point, 0.7f));
            trail.SetPosition(1, point);
            if (t >= 1) gameObject.SetActive(false);
        }
    }
}
