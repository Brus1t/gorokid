using UnityEngine;

namespace ARCardPrototype
{
    public sealed class SmoothHealthBar : MonoBehaviour
    {
        [SerializeField] private float duration = 0.45f;
        private Transform fill;
        private TextMesh label;
        private float fromRatio, targetRatio, elapsed;
        public float DisplayedRatio { get; private set; }

        public void Initialize(VisualFactory factory)
        {
            factory.Shape("Background", PrimitiveType.Cube, transform, Vector3.zero,
                new Vector3(1.85f, 0.2f, 0.025f), factory.Material(new Color(0.06f, 0.09f, 0.14f)));
            fill = factory.Shape("Fill", PrimitiveType.Cube, transform, new Vector3(0, 0, -0.03f),
                new Vector3(1.8f, 0.15f, 0.025f), factory.Material(new Color(0.2f, 0.95f, 0.63f))).transform;
            label = factory.Text("HP", transform, new Vector3(0, 0.32f, -0.04f), "4 / 4", 0.05f, Color.white);
        }

        public void SetHealth(int health, int maxHealth, bool immediate = false)
        {
            if (fill == null) return;
            targetRatio = maxHealth > 0 ? Mathf.Clamp01((float)health / maxHealth) : 0;
            fromRatio = DisplayedRatio;
            elapsed = 0;
            label.text = health + " / " + maxHealth;
            if (immediate) { DisplayedRatio = targetRatio; ApplyFill(); }
        }

        private void Update()
        {
            if (fill == null || Mathf.Approximately(DisplayedRatio, targetRatio)) return;
            elapsed += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(elapsed / Mathf.Max(0.01f, duration));
            float eased = t * t * (3f - 2f * t);
            DisplayedRatio = Mathf.Lerp(fromRatio, targetRatio, eased);
            ApplyFill();
        }

        private void ApplyFill()
        {
            fill.localScale = new Vector3(1.8f * DisplayedRatio, 0.15f, 0.025f);
            fill.localPosition = new Vector3(-0.9f + 0.9f * DisplayedRatio, 0, -0.03f);
        }
    }
}
