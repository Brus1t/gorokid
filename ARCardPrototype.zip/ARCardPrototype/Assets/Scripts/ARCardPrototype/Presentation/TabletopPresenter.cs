using System;
using System.Collections.Generic;
using UnityEngine;

namespace ARCardPrototype
{
    // Presentation clock only. Damage has already been committed by GameManager.
    public sealed class TabletopPresenter : MonoBehaviour
    {
        private readonly Queue<CombatEvent> queue = new Queue<CombatEvent>();
        private GameManager game;
        private bool subscribed;
        private float duration;
        private readonly float[] from = new float[2];
        private readonly float[] target = new float[2];
        private readonly float[] healthAge = new float[2];
        public readonly float[] Health = new float[2];
        public readonly float[] HealthShadow = new float[2];
        public readonly int[] HealthText = new int[2];
        public CombatEvent Active { get; private set; }
        public float Age { get; private set; }
        public bool IsBusy { get { return Active != null || queue.Count > 0; } }
        public event Action<CombatEvent> Began;
        public int PendingCount { get { return queue.Count; } }

        public void Initialize(GameManager manager)
        {
            game = manager;
            Synchronize();
            Subscribe();
        }
        private void Subscribe()
        {
            if (game == null || subscribed || !isActiveAndEnabled) return;
            game.Events.Published += Receive;
            subscribed = true;
        }
        private void OnEnable() { if (game != null) { Synchronize(); Subscribe(); } }
        private void OnDisable()
        {
            if (subscribed) game.Events.Published -= Receive;
            subscribed = false;
            queue.Clear(); Active = null;
        }
        private void Synchronize()
        {
            queue.Clear(); Active = null; Age = 0;
            for (int i = 0; i < 2; i++)
            {
                Health[i] = HealthShadow[i] = from[i] = target[i] = game.Players[i].Health;
                HealthText[i] = game.Players[i].Health;
                healthAge[i] = 1;
            }
        }
        private void Receive(CombatEvent message)
        {
            if (message is GameResetEvent) { Synchronize(); if (Began != null) Began(message); }
            else queue.Enqueue(message);
        }
        private void SetHealth(int id, int value)
        { from[id] = Health[id]; target[id] = value; HealthText[id] = value; healthAge[id] = 0; }
        private void Update()
        {
            if (game == null) return;
            float dt = Time.unscaledDeltaTime;
            for (int i = 0; i < 2; i++)
            {
                healthAge[i] += dt;
                Health[i] = Mathf.Lerp(from[i], target[i], Mathf.SmoothStep(0, 1, healthAge[i] / 0.48f));
                if (healthAge[i] > 0.25f)
                    HealthShadow[i] = Mathf.MoveTowards(HealthShadow[i], target[i], dt * 2.5f);
            }
            if (Active != null)
            {
                Age += dt;
                if (Age >= duration) Active = null;
            }
            if (Active == null && queue.Count > 0)
            {
                Active = queue.Dequeue(); Age = 0;
                duration = Active is AttackDeclaredEvent ? 1.45f : 1.05f;
                var hit = Active as DamageEvent;
                var heal = Active as HealEvent;
                if (hit != null) SetHealth(hit.TargetId, hit.NewHealth);
                if (heal != null) SetHealth(heal.PlayerId, heal.NewHealth);
                if (Began != null) Began(Active);
            }
        }
    }
}
