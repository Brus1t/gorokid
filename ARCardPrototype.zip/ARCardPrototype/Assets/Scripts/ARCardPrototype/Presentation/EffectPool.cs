using System;
using System.Collections.Generic;
using UnityEngine;

namespace ARCardPrototype
{
    public abstract class PooledEffect : MonoBehaviour { }

    // Bounded, local pool; no global singleton or battle-manager lookup.
    public sealed class EffectPool<T> where T : PooledEffect
    {
        private readonly List<T> items = new List<T>();
        private readonly Func<T> create;
        private readonly int capacity;
        public int Count { get { return items.Count; } }

        public EffectPool(Func<T> factory, int warmCount, int maxCount)
        {
            create = factory;
            capacity = Math.Max(1, maxCount);
            for (int i = 0; i < Math.Min(warmCount, capacity); i++) Add();
        }

        private T Add()
        {
            T item = create();
            item.gameObject.SetActive(false);
            items.Add(item);
            return item;
        }

        public T Rent()
        {
            foreach (T item in items)
                if (!item.gameObject.activeSelf) { item.gameObject.SetActive(true); return item; }
            if (items.Count >= capacity) return null; // Dropped cosmetic, never dropped damage.
            T added = Add();
            added.gameObject.SetActive(true);
            return added;
        }

        public void ResetAll()
        { foreach (T item in items) item.gameObject.SetActive(false); }
    }
}
