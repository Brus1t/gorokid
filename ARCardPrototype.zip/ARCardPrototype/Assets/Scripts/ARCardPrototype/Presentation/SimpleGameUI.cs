using UnityEngine;

namespace ARCardPrototype
{
    // Desktop debug/control panel. Replace only this view when moving to AR UI.
    public sealed class SimpleGameUI : MonoBehaviour
    {
        private GameManager game;
        private IGameInput input;
        private Vector2 scroll;
        private GUIStyle labelStyle, buttonStyle, titleStyle;

        public void Initialize(GameManager manager, IGameInput gameInput)
        { game = manager; input = gameInput; }

        private void OnGUI()
        {
            if (game == null || input == null) return;
            if (labelStyle == null)
            {
                labelStyle = new GUIStyle(GUI.skin.label) { wordWrap = true, fontSize = 14 };
                buttonStyle = new GUIStyle(GUI.skin.button) { wordWrap = true, fontSize = 14 };
                titleStyle = new GUIStyle(labelStyle) { fontSize = 21, fontStyle = FontStyle.Bold };
            }
            Matrix4x4 oldMatrix = GUI.matrix;
            bool oldEnabled = GUI.enabled;
            Color oldColor = GUI.backgroundColor;
            try
            {
                float scale = Mathf.Max(0.1f, Screen.width / 1200f);
                GUI.matrix = Matrix4x4.Scale(new Vector3(scale, scale, 1));
                GUILayout.BeginArea(new Rect(10, 10, 460, Screen.height / scale - 20), GUI.skin.box);
                scroll = GUILayout.BeginScrollView(scroll);
                GUILayout.Label("AR CARD LAB", titleStyle);
                GUILayout.Label("PC prototype / local 2-player hot-seat", labelStyle);
                GUILayout.Label("1-9 select card | Q/W select player\nEnter confirm | Esc clear | E end | S take damage", labelStyle);
                GUILayout.Space(8);
                GUILayout.Label("TURN " + game.Turns.TurnNumber + "  /  " + game.CurrentPlayer.Name, titleStyle);
                GUILayout.Label("Phase: " + game.Phase + " | Attack used: " + game.Turns.AttackUsed, labelStyle);
                GUILayout.BeginHorizontal();
                foreach (Player player in game.Players)
                {
                    GUI.enabled = oldEnabled && game.Phase == GamePhase.Playing;
                    bool legal = game.SelectedCardIndex >= 0 &&
                        TargetingRules.Allows(game.ActingPlayer.Hand[game.SelectedCardIndex].Type, game.ActingPlayer.Id, player.Id);
                    GUI.backgroundColor = game.SelectedTargetId == player.Id ? Color.yellow : legal ? Color.green : oldColor;
                    if (GUILayout.Button(player.Name + "\nHP " + player.Health + "/" + player.MaxHealth +
                        " | " + player.Hand.Count + " cards", buttonStyle, GUILayout.Height(48)))
                    { input.SelectPlayer(player.Id); GUIUtility.ExitGUI(); }
                }
                GUILayout.EndHorizontal();
                GUI.backgroundColor = oldColor;
                GUI.enabled = oldEnabled;
                if (game.Phase == GamePhase.GameOver)
                    GUILayout.Label("WINNER: " + game.Players[game.WinnerId].Name, titleStyle);
                else
                    GUILayout.Label(game.Phase == GamePhase.AwaitingDodge
                        ? game.ActingPlayer.Name + ": play Dodge, or Take damage."
                        : "Attack: select card, then opponent. Peach: self target.", labelStyle);

                Player actor = game.ActingPlayer;
                GUILayout.Label("HAND - " + actor.Name, titleStyle);
                GUI.enabled = oldEnabled && game.Phase != GamePhase.GameOver;
                for (int i = 0; i < actor.Hand.Count; i++)
                {
                    GUI.backgroundColor = game.SelectedCardIndex == i ? new Color(0.3f, 0.85f, 1f) : oldColor;
                    if (GUILayout.Button((i + 1) + ". " + actor.Hand[i].Name, buttonStyle, GUILayout.Height(30)))
                    { input.SelectCard(i); GUIUtility.ExitGUI(); }
                }
                GUI.backgroundColor = oldColor;
                if (game.SelectedCardIndex >= 0)
                    GUILayout.Label(actor.Hand[game.SelectedCardIndex].Description, labelStyle);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Confirm", buttonStyle, GUILayout.Height(34))) { input.Confirm(); GUIUtility.ExitGUI(); }
                if (GUILayout.Button("Clear", buttonStyle, GUILayout.Height(34))) { input.Cancel(); GUIUtility.ExitGUI(); }
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                GUI.enabled = oldEnabled && game.Phase == GamePhase.Playing;
                if (GUILayout.Button("End turn [E]", buttonStyle, GUILayout.Height(34))) { input.EndTurn(); GUIUtility.ExitGUI(); }
                GUI.enabled = oldEnabled && game.Phase == GamePhase.AwaitingDodge;
                if (GUILayout.Button("Take damage [S]", buttonStyle, GUILayout.Height(34))) { input.SkipResponse(); GUIUtility.ExitGUI(); }
                GUILayout.EndHorizontal();
                GUI.enabled = oldEnabled;
                if (GUILayout.Button("Restart game", buttonStyle, GUILayout.Height(28))) { game.Restart(); GUIUtility.ExitGUI(); }
                GUILayout.Label("RECENT EVENTS", titleStyle);
                for (int i = game.History.Count - 1; i >= Mathf.Max(0, game.History.Count - 6); i--)
                    GUILayout.Label(game.History[i], labelStyle);
                GUILayout.EndScrollView();
                GUILayout.EndArea();
            }
            finally
            {
                GUI.matrix = oldMatrix;
                GUI.enabled = oldEnabled;
                GUI.backgroundColor = oldColor;
            }
        }
    }
}
