using UnityEngine;

namespace ARCardPrototype
{
    public sealed class DamagePopup : PooledEffect
    {
        private TextMesh label;
        private Camera viewCamera;
        private Vector3 origin;
        private Color baseColor;
        private float age;
        public void Initialize(VisualFactory factory, Camera camera)
        {
            viewCamera = camera;
            label = factory.Text("Value", transform, Vector3.zero, "", 0.1f, Color.white);
        }
        public void Show(Vector3 position, string value, Color color)
        {
            age = 0;
            origin = position;
            baseColor = color;
            label.text = value;
            label.color = color;
            transform.position = origin;
        }
        private void Update()
        {
            age += Time.unscaledDeltaTime;
            float t = Mathf.Clamp01(age / 0.9f);
            transform.position = origin + Vector3.up * t * 0.65f;
            if (viewCamera != null) transform.rotation = viewCamera.transform.rotation;
            Color color = baseColor;
            color.a = 1f - Mathf.SmoothStep(0, 1, Mathf.InverseLerp(0.35f, 1f, t));
            label.color = color;
            if (t >= 1) gameObject.SetActive(false);
        }
    }
}
