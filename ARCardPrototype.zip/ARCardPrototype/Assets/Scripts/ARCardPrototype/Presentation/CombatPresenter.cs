using System;
using System.Collections.Generic;
using UnityEngine;

namespace ARCardPrototype
{
    public sealed class CombatPresenter : MonoBehaviour
    {
        private readonly Queue<CombatEvent> pending = new Queue<CombatEvent>();
        private readonly PlayerView[] views = new PlayerView[2];
        private GameManager game;
        private VisualFactory factory;
        private EffectPool<AttackVfx> attacks;
        private EffectPool<DamagePopup> popups;
        private float wait;
        private bool subscribed;
        private Transform stage;
        private Camera stageCamera;
        public event Action<CombatEvent> Presented;
        public PlayerView GetView(int id) { return views[id]; }
        public int PendingCount { get { return pending.Count; } }
        public int PopupPoolSize { get { return popups == null ? 0 : popups.Count; } }
        public int AttackPoolSize { get { return attacks == null ? 0 : attacks.Count; } }

        public void Initialize(GameManager manager)
        {
            game = manager;
            factory = new VisualFactory();
            stage = new GameObject("GeneratedArena").transform;
            stage.SetParent(transform, false);
            // A separate camera keeps the demo from repositioning the user's camera.
            stageCamera = new GameObject("PrototypeCamera").AddComponent<Camera>();
            stageCamera.transform.SetParent(stage, false);
            stageCamera.transform.position = new Vector3(0, 4.8f, -9);
            stageCamera.transform.LookAt(new Vector3(0, 1.3f, 0));
            stageCamera.orthographic = true;
            stageCamera.orthographicSize = 3.8f;
            stageCamera.depth = 10;
            stageCamera.rect = new Rect(0.4f, 0, 0.6f, 1);
            stageCamera.clearFlags = CameraClearFlags.SolidColor;
            stageCamera.backgroundColor = new Color(0.025f, 0.045f, 0.08f);
            factory.Shape("Table", PrimitiveType.Cube, stage, new Vector3(0, -0.15f, 0),
                new Vector3(7, 0.2f, 4), factory.Material(new Color(0.075f, 0.12f, 0.17f)));
            for (int i = 0; i < views.Length; i++)
            {
                var obj = new GameObject("PlayerView" + i);
                obj.transform.SetParent(stage, false);
                obj.transform.localPosition = new Vector3(i == 0 ? -2f : 2f, 0, 0);
                views[i] = obj.AddComponent<PlayerView>();
                views[i].Initialize(factory, stageCamera, i);
            }
            attacks = new EffectPool<AttackVfx>(() =>
            {
                var obj = new GameObject("PooledAttack"); obj.transform.SetParent(stage, false);
                var effect = obj.AddComponent<AttackVfx>(); effect.Initialize(factory); return effect;
            }, 2, 8);
            popups = new EffectPool<DamagePopup>(() =>
            {
                var obj = new GameObject("PooledPopup"); obj.transform.SetParent(stage, false);
                var effect = obj.AddComponent<DamagePopup>(); effect.Initialize(factory, stageCamera); return effect;
            }, 4, 16);
            ResetVisuals();
            Subscribe();
        }

        private void Subscribe()
        {
            if (game == null || subscribed || !isActiveAndEnabled) return;
            game.Events.Published += Receive;
            subscribed = true;
        }
        private void OnEnable()
        {
            if (game == null) return;
            stage.gameObject.SetActive(true);
            ResetVisuals();
            Subscribe();
        }
        private void OnDisable()
        {
            if (subscribed) { game.Events.Published -= Receive; subscribed = false; }
            pending.Clear();
            if (stage != null) stage.gameObject.SetActive(false);
        }
        private void OnDestroy() { if (factory != null) factory.Dispose(); }

        private void Receive(CombatEvent message)
        {
            // Restart is a barrier: do not replay old attacks against a new game.
            if (message is GameResetEvent) { ResetVisuals(); Dispatch(message); }
            else pending.Enqueue(message);
        }
        private void ResetVisuals()
        {
            pending.Clear(); wait = 0;
            attacks.ResetAll(); popups.ResetAll();
            for (int i = 0; i < views.Length; i++)
            {
                views[i].HealthBar.SetHealth(game.Players[i].Health, game.Players[i].MaxHealth, true);
                views[i].Feedback.ResetFeedback();
                views[i].SetSelected(false);
            }
        }
        private void Update()
        {
            if (game == null) return;
            for (int i = 0; i < views.Length; i++) views[i].SetSelected(game.SelectedTargetId == i);
            wait = Mathf.Max(0, wait - Time.unscaledDeltaTime);
            if (wait > 0 || pending.Count == 0) return;
            CombatEvent message = pending.Dequeue();
            var attack = message as AttackDeclaredEvent;
            var damage = message as DamageEvent;
            var heal = message as HealEvent;
            var dodge = message as DodgeEvent;
            if (attack != null)
            {
                AttackVfx effect = attacks.Rent();
                if (effect != null) effect.Launch(views[attack.SourceId].HitPoint, views[attack.TargetId].HitPoint);
                wait = AttackVfx.Duration;
            }
            else if (damage != null)
            {
                PlayerView view = views[damage.TargetId];
                view.HealthBar.SetHealth(damage.NewHealth, damage.MaxHealth);
                view.Feedback.Play();
                Popup(damage.TargetId, "-" + damage.Amount, new Color(1f, 0.3f, 0.27f));
                wait = 0.48f;
            }
            else if (heal != null)
            {
                views[heal.PlayerId].HealthBar.SetHealth(heal.NewHealth, heal.MaxHealth);
                Popup(heal.PlayerId, "+" + heal.Amount, new Color(0.25f, 1f, 0.6f));
                wait = 0.48f;
            }
            else if (dodge != null) { Popup(dodge.PlayerId, "DODGE", Color.cyan); wait = 0.3f; }
            Dispatch(message);
        }
        private void Popup(int id, string text, Color color)
        {
            DamagePopup popup = popups.Rent();
            if (popup != null) popup.Show(views[id].PopupPoint + Vector3.back * 0.4f, text, color);
        }
        private void Dispatch(CombatEvent message) { if (Presented != null) Presented(message); }
    }
}
