using UnityEngine;

namespace ARCardPrototype
{
    public sealed class PlayerView : MonoBehaviour
    {
        private Camera viewCamera;
        private Transform nameLabel;
        private GameObject selectionMarker;
        public SmoothHealthBar HealthBar { get; private set; }
        public HitFeedback Feedback { get; private set; }
        public Vector3 HitPoint { get { return transform.position + Vector3.up * 1.1f; } }
        public Vector3 PopupPoint { get { return transform.position + Vector3.up * 1.3f + Vector3.right * 0.95f; } }

        public void Initialize(VisualFactory factory, Camera camera, int playerId)
        {
            viewCamera = camera;
            Color color = playerId == 0 ? new Color(0.22f, 0.65f, 1f) : new Color(1f, 0.47f, 0.25f);
            GameObject avatar = factory.Shape("Avatar", PrimitiveType.Capsule, transform,
                new Vector3(0, 0.8f, 0), new Vector3(0.8f, 0.8f, 0.8f), factory.Material(color));
            Feedback = avatar.AddComponent<HitFeedback>();
            Feedback.Initialize(avatar.GetComponent<Renderer>(), color);
            selectionMarker = factory.Shape("TargetMarker", PrimitiveType.Cylinder, transform,
                new Vector3(0, 0.03f, 0), new Vector3(1.2f, 0.025f, 1.2f), factory.Material(new Color(1f, 0.85f, 0.2f)));
            selectionMarker.SetActive(false);
            var barObject = new GameObject("HealthBar");
            barObject.transform.SetParent(transform, false);
            barObject.transform.localPosition = new Vector3(0, 2.15f, 0);
            HealthBar = barObject.AddComponent<SmoothHealthBar>();
            HealthBar.Initialize(factory);
            nameLabel = factory.Text("Name", transform, new Vector3(0, 2.85f, 0),
                "PLAYER " + (playerId + 1), 0.055f, color).transform;
        }

        public void SetSelected(bool selected) { selectionMarker.SetActive(selected); }
        private void LateUpdate()
        {
            if (viewCamera == null) return;
            HealthBar.transform.rotation = viewCamera.transform.rotation;
            nameLabel.rotation = viewCamera.transform.rotation;
        }
    }
}
