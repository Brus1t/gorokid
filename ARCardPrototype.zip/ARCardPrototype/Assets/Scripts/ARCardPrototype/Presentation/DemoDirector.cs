using System.Collections;
using UnityEngine;

namespace ARCardPrototype
{
    // Scripted demonstration issues legal game commands; it never edits player HP.
    public sealed class DemoDirector : MonoBehaviour
    {
        private GameManager game;
        private TabletopPresenter presenter;
        private Coroutine routine;
        public bool IsRunning { get; private set; }
        public string Caption { get; private set; }
        public int Step { get; private set; }

        public void Initialize(GameManager manager, TabletopPresenter visual)
        { game = manager; presenter = visual; Caption = ""; }

        private IEnumerator Start()
        {
            if (System.Array.IndexOf(System.Environment.GetCommandLineArgs(), "-autodemo") < 0) yield break;
            while (!UnityEngine.Rendering.SplashScreen.isFinished) yield return null;
            yield return new WaitForSecondsRealtime(0.5f);
            Play();
        }

        public void Play()
        {
            if (IsRunning || game == null) return;
            routine = StartCoroutine(Sequence());
        }
        public void Stop()
        {
            if (routine != null) StopCoroutine(routine);
            routine = null; IsRunning = false; Caption = ""; Step = 0;
            if (game != null) game.Restart();
        }
        private void OnDisable() { if (IsRunning) Stop(); }
        private IEnumerator Pause(float seconds)
        {
            yield return new WaitForSecondsRealtime(seconds);
            while (presenter.IsBusy) yield return null;
        }
        private void Select(CardType type)
        {
            for (int i = 0; i < game.ActingPlayer.Hand.Count; i++)
                if (game.ActingPlayer.Hand[i].Type == type) { game.SelectCard(i); return; }
        }
        private IEnumerator Sequence()
        {
            IsRunning = true; game.Restart();
            Step = 1; Caption = "第一幕 · 出杀与闪避";
            yield return Pause(1.2f);
            Select(CardType.Attack);
            yield return Pause(0.65f);
            game.SelectPlayer(1);
            yield return Pause(0.65f);
            game.Confirm();
            yield return Pause(1.65f);
            Caption = "赤曜打出「闪」，抵消这次攻击";
            Select(CardType.Dodge);
            yield return Pause(0.65f);
            game.Confirm();
            yield return Pause(1.8f);
            game.Restart();
            Step = 2; Caption = "第二幕 · 承受伤害";
            yield return Pause(0.7f);
            Select(CardType.Attack); game.SelectPlayer(1);
            yield return Pause(0.6f);
            game.Confirm();
            yield return Pause(1.6f);
            Caption = "不出闪：受到 1 点伤害，体力降至 3 / 4";
            game.SkipResponse();
            yield return Pause(2.0f);
            Step = 3; Caption = "第三幕 · 回合切换与恢复";
            game.EndTurn();
            yield return Pause(0.9f);
            Select(CardType.Peach);
            yield return Pause(0.75f);
            game.Confirm();
            yield return Pause(1.5f);
            Caption = "演示完成 · 现在由你接手";
            IsRunning = false; routine = null;
        }
    }
}
