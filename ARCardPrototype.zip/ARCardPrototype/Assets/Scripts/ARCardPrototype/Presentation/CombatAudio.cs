using UnityEngine;

namespace ARCardPrototype
{
    // Optional clips supplied by the developer; no third-party sounds shipped.
    [RequireComponent(typeof(AudioSource))]
    public sealed class CombatAudio : MonoBehaviour
    {
        [SerializeField] private AudioClip attack;
        [SerializeField] private AudioClip damage;
        [SerializeField] private AudioClip dodge;
        [SerializeField] private AudioClip heal;
        private CombatPresenter presenter;
        private AudioSource source;
        private bool subscribed;

        public void Initialize(CombatPresenter combatPresenter)
        {
            Unsubscribe();
            presenter = combatPresenter;
            source = GetComponent<AudioSource>();
            source.playOnAwake = false;
            source.volume = 0.35f;
            Subscribe();
        }
        private void Subscribe()
        {
            if (presenter == null || subscribed || !isActiveAndEnabled) return;
            presenter.Presented += Play;
            subscribed = true;
        }
        private void Unsubscribe()
        {
            if (presenter != null && subscribed) presenter.Presented -= Play;
            subscribed = false;
        }
        private void OnEnable() { Subscribe(); }
        private void OnDisable()
        {
            Unsubscribe();
            if (source != null) source.Stop();
        }
        private void Play(CombatEvent message)
        {
            if (message is GameResetEvent) { source.Stop(); return; }
            AudioClip clip = message is AttackDeclaredEvent ? attack : message is DamageEvent ? damage :
                message is DodgeEvent ? dodge : message is HealEvent ? heal : null;
            if (clip != null) source.PlayOneShot(clip);
        }
    }
}
