using UnityEngine;

namespace ARCardPrototype
{
    // Code-drawn cards and interface; no third-party icons or card faces.
    public static class InkDraw
    {
        public static readonly Color Gold = new Color(0.79f, 0.65f, 0.39f);
        public static readonly Color Paper = new Color(0.91f, 0.86f, 0.74f);
        public static readonly Color Jade = new Color(0.38f, 0.77f, 0.70f);
        public static readonly Color Red = new Color(0.88f, 0.38f, 0.28f);
        public static readonly Color Ink = new Color(0.04f, 0.08f, 0.085f);

        public static void Fill(Rect rect, Color color)
        { Color old = GUI.color; GUI.color = color; GUI.DrawTexture(rect, Texture2D.whiteTexture); GUI.color = old; }
        public static void Border(Rect r, Color color, float width = 1)
        {
            Fill(new Rect(r.x, r.y, r.width, width), color);
            Fill(new Rect(r.x, r.yMax - width, r.width, width), color);
            Fill(new Rect(r.x, r.y, width, r.height), color);
            Fill(new Rect(r.xMax - width, r.y, width, r.height), color);
        }
        public static void Line(Vector2 a, Vector2 b, Color color, float width = 1)
        {
            Matrix4x4 old = GUI.matrix;
            GUIUtility.RotateAroundPivot(Mathf.Atan2(b.y - a.y, b.x - a.x) * Mathf.Rad2Deg, a);
            Fill(new Rect(a.x, a.y - width / 2, Vector2.Distance(a, b), width), color);
            GUI.matrix = old;
        }
        public static void Ring(Vector2 center, float radius, Color color, float width = 1, float rotation = 0, float fraction = 1)
        {
            const int segments = 72;
            for (int i = 0; i < segments * fraction; i++)
            {
                float a = rotation + i * Mathf.PI * 2 / segments;
                float b = rotation + (i + 1) * Mathf.PI * 2 / segments;
                Line(center + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * radius,
                    center + new Vector2(Mathf.Cos(b), Mathf.Sin(b)) * radius, color, width);
            }
        }
        public static void Diamond(Vector2 point, float size, Color color)
        {
            Matrix4x4 old = GUI.matrix; GUIUtility.RotateAroundPivot(45, point);
            Fill(new Rect(point.x - size / 2, point.y - size / 2, size, size), color);
            GUI.matrix = old;
        }
        public static void Text(Rect rect, string text, int size, Color color, Font font,
            TextAnchor anchor = TextAnchor.MiddleLeft, FontStyle weight = FontStyle.Normal)
        {
            var style = new GUIStyle(GUI.skin.label) { font = font, fontSize = size,
                alignment = anchor, fontStyle = weight, wordWrap = true, richText = false };
            style.normal.textColor = color;
            GUI.Label(rect, text, style);
        }
    }
}
