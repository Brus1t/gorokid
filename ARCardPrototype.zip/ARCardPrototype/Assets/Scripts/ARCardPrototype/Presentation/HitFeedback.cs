using UnityEngine;

namespace ARCardPrototype
{
    public sealed class HitFeedback : MonoBehaviour
    {
        private Renderer body;
        private Color originalColor;
        private Vector3 restPosition;
        private MaterialPropertyBlock properties;
        private float remaining;
        public bool IsPlaying { get { return remaining > 0; } }

        public void Initialize(Renderer renderer, Color color)
        {
            body = renderer; originalColor = color; restPosition = transform.localPosition;
            properties = new MaterialPropertyBlock();
        }

        public void Play() { remaining = 0.35f; }

        private void Update()
        {
            if (body == null || remaining <= 0) return;
            remaining = Mathf.Max(0, remaining - Time.unscaledDeltaTime);
            float strength = remaining / 0.35f;
            // Shake the avatar only: never move the camera or an eventual AR anchor.
            transform.localPosition = restPosition + Vector3.right * (Mathf.Sin(remaining * 100f) * 0.12f * strength);
            Color color = remaining > 0 && Mathf.Sin(remaining * 65f) > 0 ? Color.white : originalColor;
            properties.SetColor("_BaseColor", color);
            properties.SetColor("_Color", color);
            body.SetPropertyBlock(properties);
            if (remaining <= 0) ResetFeedback();
        }

        public void ResetFeedback()
        {
            remaining = 0;
            transform.localPosition = restPosition;
            if (body != null) body.SetPropertyBlock(null);
        }

        private void OnDisable() { ResetFeedback(); }
    }
}
